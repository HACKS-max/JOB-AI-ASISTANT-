import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { jobs } from "@db/schema";
import { eq, and, desc } from "drizzle-orm";

export const jobRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        status: z.string().optional(),
        source: z.string().optional(),
        search: z.string().optional(),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];

      if (input?.status && input.status !== "all") {
        conditions.push(eq(jobs.status, input.status as "new" | "saved" | "applied" | "viewed" | "interview" | "rejected" | "hired"));
      }
      if (input?.source && input.source !== "all") {
        conditions.push(eq(jobs.source, input.source as "upwork" | "linkedin" | "indeed" | "freelancer" | "other"));
      }

      const query = conditions.length > 0
        ? db.select().from(jobs).where(and(...conditions)).orderBy(desc(jobs.createdAt))
        : db.select().from(jobs).orderBy(desc(jobs.createdAt));

      return query;
    }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db.select().from(jobs).where(eq(jobs.id, input.id));
      return result[0] || null;
    }),

  create: publicQuery
    .input(
      z.object({
        title: z.string().min(1),
        company: z.string().optional(),
        source: z.enum(["upwork", "linkedin", "indeed", "freelancer", "other"]).default("other"),
        sourceUrl: z.string().optional(),
        description: z.string().optional(),
        requirements: z.string().optional(),
        budget: z.string().optional(),
        budgetType: z.enum(["hourly", "fixed"]).default("hourly"),
        skills: z.array(z.string()).optional(),
        userId: z.number(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { userId, ...data } = input;
      const result = await db.insert(jobs).values({
        ...data,
        userId: userId,
        skills: data.skills || [],
      });
      return result;
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        title: z.string().optional(),
        company: z.string().optional(),
        description: z.string().optional(),
        requirements: z.string().optional(),
        budget: z.string().optional(),
        status: z.enum(["new", "saved", "applied", "viewed", "interview", "rejected", "hired"]).optional(),
        proposal: z.string().optional(),
        appliedAt: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(jobs).set({
        ...data,
        appliedAt: data.appliedAt ? new Date(data.appliedAt) : undefined,
      }).where(eq(jobs.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(jobs).where(eq(jobs.id, input.id));
      return { success: true };
    }),

  stats: publicQuery.query(async () => {
    const db = getDb();
    const allJobs = await db.select().from(jobs);
    return {
      total: allJobs.length,
      new: allJobs.filter(j => j.status === "new").length,
      saved: allJobs.filter(j => j.status === "saved").length,
      applied: allJobs.filter(j => j.status === "applied").length,
      interview: allJobs.filter(j => j.status === "interview").length,
    };
  }),
});
