import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { calls } from "@db/schema";
import { eq, and, desc, gte } from "drizzle-orm";

export const callRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        status: z.string().optional(),
        dateFrom: z.string().optional(),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];

      if (input?.status && input.status !== "all") {
        conditions.push(eq(calls.status, input.status as "scheduled" | "in_progress" | "completed" | "cancelled" | "no_answer"));
      }
      if (input?.dateFrom) {
        conditions.push(gte(calls.scheduledAt, new Date(input.dateFrom)));
      }

      const query = conditions.length > 0
        ? db.select().from(calls).where(and(...conditions)).orderBy(desc(calls.scheduledAt))
        : db.select().from(calls).orderBy(desc(calls.scheduledAt));

      return query;
    }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db.select().from(calls).where(eq(calls.id, input.id));
      return result[0] || null;
    }),

  create: publicQuery
    .input(
      z.object({
        contactId: z.number().optional(),
        title: z.string().min(1),
        purpose: z.string().optional(),
        scheduledAt: z.string(),
        duration: z.number().min(5).max(480).optional(),
        userId: z.number(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { userId, ...data } = input;
      const result = await db.insert(calls).values({
        ...data,
        userId: userId,
        contactId: data.contactId ? data.contactId : null,
        scheduledAt: new Date(data.scheduledAt),
        status: "scheduled",
      });
      return result;
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        title: z.string().optional(),
        purpose: z.string().optional(),
        scheduledAt: z.string().optional(),
        duration: z.number().optional(),
        status: z.enum(["scheduled", "in_progress", "completed", "cancelled", "no_answer"]).optional(),
        notes: z.string().optional(),
        outcome: z.enum(["successful", "follow_up_needed", "no_answer", "voicemail"]).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(calls).set({
        ...data,
        scheduledAt: data.scheduledAt ? new Date(data.scheduledAt) : undefined,
      }).where(eq(calls.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(calls).where(eq(calls.id, input.id));
      return { success: true };
    }),

  stats: publicQuery.query(async () => {
    const db = getDb();
    const allCalls = await db.select().from(calls);
    return {
      total: allCalls.length,
      scheduled: allCalls.filter(c => c.status === "scheduled").length,
      completed: allCalls.filter(c => c.status === "completed").length,
      cancelled: allCalls.filter(c => c.status === "cancelled").length,
    };
  }),
});
