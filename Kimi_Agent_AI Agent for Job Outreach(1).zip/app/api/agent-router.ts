import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { agentConfigs, integrations, apiKeys } from "@db/schema";
import { eq } from "drizzle-orm";

export const agentRouter = createRouter({
  getConfig: publicQuery
    .input(z.object({ userId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db.select().from(agentConfigs).where(eq(agentConfigs.userId, input.userId));
      return result[0] || null;
    }),

  upsertConfig: publicQuery
    .input(
      z.object({
        userId: z.number(),
        agentName: z.string().optional(),
        autonomyLevel: z.enum(["manual", "assisted", "autonomous"]).optional(),
        dailyTaskLimit: z.number().min(1).max(500).optional(),
        workingHoursStart: z.string().optional(),
        workingHoursEnd: z.string().optional(),
        timezone: z.string().optional(),
        language: z.string().optional(),
        isActive: z.boolean().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const existing = await db.select().from(agentConfigs).where(eq(agentConfigs.userId, input.userId));
      
      if (existing.length > 0) {
        await db.update(agentConfigs).set({
          agentName: input.agentName,
          autonomyLevel: input.autonomyLevel,
          dailyTaskLimit: input.dailyTaskLimit,
          workingHoursStart: input.workingHoursStart,
          workingHoursEnd: input.workingHoursEnd,
          timezone: input.timezone,
          language: input.language,
          isActive: input.isActive,
        }).where(eq(agentConfigs.userId, input.userId));
        return { ...existing[0], ...input };
      } else {
        await db.insert(agentConfigs).values({
          userId: input.userId,
          agentName: input.agentName || "Nexus-1",
          autonomyLevel: input.autonomyLevel || "autonomous",
          dailyTaskLimit: input.dailyTaskLimit || 50,
          workingHoursStart: input.workingHoursStart || "09:00:00",
          workingHoursEnd: input.workingHoursEnd || "18:00:00",
          timezone: input.timezone || "UTC",
          language: input.language || "en",
          isActive: input.isActive ?? true,
        });
        const result = await db.select().from(agentConfigs).where(eq(agentConfigs.userId, input.userId));
        return result[0];
      }
    }),

  getIntegrations: publicQuery
    .input(z.object({ userId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db.select().from(integrations).where(eq(integrations.userId, input.userId));
    }),

  updateIntegration: publicQuery
    .input(
      z.object({
        id: z.number(),
        status: z.enum(["connected", "disconnected", "error"]).optional(),
        config: z.record(z.any()).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(integrations).set(data).where(eq(integrations.id, id));
      return { success: true };
    }),

  getApiKeys: publicQuery
    .input(z.object({ userId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db.select({
        id: apiKeys.id,
        name: apiKeys.name,
        keyMask: apiKeys.keyMask,
        lastUsed: apiKeys.lastUsed,
        usageCount: apiKeys.usageCount,
        isActive: apiKeys.isActive,
        createdAt: apiKeys.createdAt,
      }).from(apiKeys).where(eq(apiKeys.userId, input.userId));
    }),

  createApiKey: publicQuery
    .input(
      z.object({
        userId: z.number(),
        name: z.string().min(1),
        keyMask: z.string(),
        keyHash: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db.insert(apiKeys).values({
        userId: input.userId,
        name: input.name,
        keyMask: input.keyMask,
        keyHash: input.keyHash,
      });
      return result;
    }),

  revokeApiKey: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(apiKeys).set({ isActive: false }).where(eq(apiKeys.id, input.id));
      return { success: true };
    }),

  stats: publicQuery
    .input(z.object({ userId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const configs = await db.select().from(agentConfigs).where(eq(agentConfigs.userId, input.userId));
      const integrationList = await db.select().from(integrations).where(eq(integrations.userId, input.userId));
      const keyList = await db.select().from(apiKeys).where(eq(apiKeys.userId, input.userId));
      
      return {
        config: configs[0] || null,
        integrations: {
          total: integrationList.length,
          connected: integrationList.filter(i => i.status === "connected").length,
        },
        apiKeys: {
          total: keyList.length,
          active: keyList.filter(k => k.isActive).length,
        },
      };
    }),
});
