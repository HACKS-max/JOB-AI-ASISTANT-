import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { tasks } from "@db/schema";
import { eq, and, desc } from "drizzle-orm";

export const taskRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        status: z.string().optional(),
        priority: z.string().optional(),
        search: z.string().optional(),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];
      
      if (input?.status && input.status !== "all") {
        conditions.push(eq(tasks.status, input.status as "backlog" | "in_progress" | "review" | "done" | "failed"));
      }
      if (input?.priority && input.priority !== "all") {
        conditions.push(eq(tasks.priority, input.priority as "low" | "medium" | "high" | "urgent"));
      }

      const query = conditions.length > 0
        ? db.select().from(tasks).where(and(...conditions)).orderBy(desc(tasks.createdAt))
        : db.select().from(tasks).orderBy(desc(tasks.createdAt));

      return query;
    }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db.select().from(tasks).where(eq(tasks.id, input.id));
      return result[0] || null;
    }),

  create: publicQuery
    .input(
      z.object({
        title: z.string().min(1),
        description: z.string().optional(),
        status: z.enum(["backlog", "in_progress", "review", "done", "failed"]).default("backlog"),
        priority: z.enum(["low", "medium", "high", "urgent"]).default("medium"),
        assignee: z.string().optional(),
        dueDate: z.string().optional(),
        tags: z.array(z.string()).optional(),
        subtasks: z.array(z.object({ title: z.string(), done: z.boolean() })).optional(),
        userId: z.number(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { userId, ...data } = input;
      const result = await db.insert(tasks).values({
        ...data,
        userId: userId,
        tags: data.tags || [],
        subtasks: data.subtasks || [],
        dueDate: data.dueDate ? new Date(data.dueDate) : null,
      });
      return result;
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        status: z.enum(["backlog", "in_progress", "review", "done", "failed"]).optional(),
        priority: z.enum(["low", "medium", "high", "urgent"]).optional(),
        assignee: z.string().optional(),
        dueDate: z.string().optional(),
        tags: z.array(z.string()).optional(),
        subtasks: z.array(z.object({ title: z.string(), done: z.boolean() })).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(tasks).set({
        ...data,
        dueDate: data.dueDate ? new Date(data.dueDate) : undefined,
      }).where(eq(tasks.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(tasks).where(eq(tasks.id, input.id));
      return { success: true };
    }),

  stats: publicQuery.query(async () => {
    const db = getDb();
    const allTasks = await db.select().from(tasks);
    return {
      total: allTasks.length,
      backlog: allTasks.filter(t => t.status === "backlog").length,
      inProgress: allTasks.filter(t => t.status === "in_progress").length,
      review: allTasks.filter(t => t.status === "review").length,
      done: allTasks.filter(t => t.status === "done").length,
      failed: allTasks.filter(t => t.status === "failed").length,
    };
  }),
});
