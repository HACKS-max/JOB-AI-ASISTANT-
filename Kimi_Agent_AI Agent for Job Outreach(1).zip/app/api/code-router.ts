import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { codeProjects } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const codeRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(codeProjects).orderBy(desc(codeProjects.updatedAt));
  }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db.select().from(codeProjects).where(eq(codeProjects.id, input.id));
      return result[0] || null;
    }),

  create: publicQuery
    .input(
      z.object({
        name: z.string().min(1),
        language: z.string().optional(),
        framework: z.string().optional(),
        description: z.string().optional(),
        files: z.array(z.object({
          name: z.string(),
          content: z.string(),
          language: z.string(),
        })).optional(),
        userId: z.number(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { userId, ...data } = input;
      const result = await db.insert(codeProjects).values({
        ...data,
        userId: userId,
        files: data.files || [],
      });
      return result;
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().optional(),
        language: z.string().optional(),
        framework: z.string().optional(),
        description: z.string().optional(),
        files: z.array(z.object({
          name: z.string(),
          content: z.string(),
          language: z.string(),
        })).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(codeProjects).set(data).where(eq(codeProjects.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(codeProjects).where(eq(codeProjects.id, input.id));
      return { success: true };
    }),
});
