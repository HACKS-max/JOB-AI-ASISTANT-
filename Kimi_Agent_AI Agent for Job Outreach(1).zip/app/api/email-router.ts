import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { emails } from "@db/schema";
import { eq, and, desc } from "drizzle-orm";

export const emailRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        status: z.string().optional(),
        search: z.string().optional(),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];

      if (input?.status && input.status !== "all") {
        conditions.push(eq(emails.status, input.status as "draft" | "scheduled" | "sent" | "failed"));
      }

      const query = conditions.length > 0
        ? db.select().from(emails).where(and(...conditions)).orderBy(desc(emails.createdAt))
        : db.select().from(emails).orderBy(desc(emails.createdAt));

      return query;
    }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db.select().from(emails).where(eq(emails.id, input.id));
      return result[0] || null;
    }),

  create: publicQuery
    .input(
      z.object({
        fromEmail: z.string().email().optional(),
        toEmails: z.array(z.string().email()),
        ccEmails: z.array(z.string().email()).optional(),
        bccEmails: z.array(z.string().email()).optional(),
        subject: z.string().min(1),
        body: z.string().min(1),
        bodyHtml: z.string().optional(),
        template: z.string().optional(),
        scheduledAt: z.string().optional(),
        userId: z.number(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { userId, ...data } = input;
      const result = await db.insert(emails).values({
        ...data,
        userId: userId,
        status: data.scheduledAt ? "scheduled" : "sent",
        sentAt: data.scheduledAt ? null : new Date(),
        scheduledAt: data.scheduledAt ? new Date(data.scheduledAt) : null,
        tracking: { opens: 0, clicks: 0 },
      });
      return result;
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        toEmails: z.array(z.string().email()).optional(),
        ccEmails: z.array(z.string().email()).optional(),
        bccEmails: z.array(z.string().email()).optional(),
        subject: z.string().optional(),
        body: z.string().optional(),
        bodyHtml: z.string().optional(),
        status: z.enum(["draft", "scheduled", "sent", "failed"]).optional(),
        scheduledAt: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(emails).set({
        ...data,
        scheduledAt: data.scheduledAt ? new Date(data.scheduledAt) : undefined,
      }).where(eq(emails.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(emails).where(eq(emails.id, input.id));
      return { success: true };
    }),

  stats: publicQuery.query(async () => {
    const db = getDb();
    const allEmails = await db.select().from(emails);
    return {
      total: allEmails.length,
      sent: allEmails.filter(e => e.status === "sent").length,
      scheduled: allEmails.filter(e => e.status === "scheduled").length,
      draft: allEmails.filter(e => e.status === "draft").length,
      failed: allEmails.filter(e => e.status === "failed").length,
    };
  }),
});
