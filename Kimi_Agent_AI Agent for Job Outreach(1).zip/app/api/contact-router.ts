import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { contacts } from "@db/schema";
import { eq, and, desc, like, or } from "drizzle-orm";

export const contactRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        category: z.string().optional(),
        search: z.string().optional(),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      
      if (input?.search) {
        const searchTerm = `%${input.search}%`;
        return db.select().from(contacts).where(
          or(
            like(contacts.name, searchTerm),
            like(contacts.email, searchTerm),
            like(contacts.company, searchTerm)
          )
        ).orderBy(desc(contacts.createdAt));
      }

      if (input?.category && input.category !== "all") {
        return db.select().from(contacts)
          .where(eq(contacts.category, input.category as "client" | "lead" | "team" | "vendor" | "other"))
          .orderBy(desc(contacts.createdAt));
      }

      return db.select().from(contacts).orderBy(desc(contacts.createdAt));
    }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db.select().from(contacts).where(eq(contacts.id, input.id));
      return result[0] || null;
    }),

  create: publicQuery
    .input(
      z.object({
        name: z.string().min(1),
        email: z.string().email().optional(),
        phone: z.string().optional(),
        company: z.string().optional(),
        role: z.string().optional(),
        category: z.enum(["client", "lead", "team", "vendor", "other"]).default("other"),
        tags: z.array(z.string()).optional(),
        notes: z.string().optional(),
        userId: z.number(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { userId, ...data } = input;
      const result = await db.insert(contacts).values({
        ...data,
        userId: userId,
        tags: data.tags || [],
      });
      return result;
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().optional(),
        email: z.string().email().optional(),
        phone: z.string().optional(),
        company: z.string().optional(),
        role: z.string().optional(),
        category: z.enum(["client", "lead", "team", "vendor", "other"]).optional(),
        tags: z.array(z.string()).optional(),
        notes: z.string().optional(),
        lastContacted: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(contacts).set({
        ...data,
        lastContacted: data.lastContacted ? new Date(data.lastContacted) : undefined,
      }).where(eq(contacts.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(contacts).where(eq(contacts.id, input.id));
      return { success: true };
    }),

  stats: publicQuery.query(async () => {
    const db = getDb();
    const allContacts = await db.select().from(contacts);
    return {
      total: allContacts.length,
      clients: allContacts.filter(c => c.category === "client").length,
      leads: allContacts.filter(c => c.category === "lead").length,
      team: allContacts.filter(c => c.category === "team").length,
      vendors: allContacts.filter(c => c.category === "vendor").length,
    };
  }),
});
