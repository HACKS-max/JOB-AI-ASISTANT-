import { authRouter } from "./auth-router";
import { taskRouter } from "./task-router";
import { emailRouter } from "./email-router";
import { callRouter } from "./call-router";
import { jobRouter } from "./job-router";
import { contactRouter } from "./contact-router";
import { codeRouter } from "./code-router";
import { activityRouter } from "./activity-router";
import { agentRouter } from "./agent-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  task: taskRouter,
  email: emailRouter,
  call: callRouter,
  job: jobRouter,
  contact: contactRouter,
  code: codeRouter,
  activity: activityRouter,
  agent: agentRouter,
});

export type AppRouter = typeof appRouter;
