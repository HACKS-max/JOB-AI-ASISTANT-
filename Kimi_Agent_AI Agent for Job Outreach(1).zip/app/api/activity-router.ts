import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { activityLog } from "@db/schema";
import { eq, desc, gte } from "drizzle-orm";

export const activityRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        type: z.string().optional(),
        limit: z.number().min(1).max(100).default(50),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const limit = input?.limit || 50;
      
      if (input?.type && input.type !== "all") {
        return db.select().from(activityLog)
          .where(eq(activityLog.type, input.type as "task" | "email" | "call" | "code" | "job" | "system"))
          .orderBy(desc(activityLog.createdAt))
          .limit(limit);
      }

      return db.select().from(activityLog).orderBy(desc(activityLog.createdAt)).limit(limit);
    }),

  create: publicQuery
    .input(
      z.object({
        type: z.enum(["task", "email", "call", "code", "job", "system"]),
        action: z.string().min(1),
        details: z.record(z.any()).optional(),
        status: z.enum(["success", "warning", "error", "info"]).default("info"),
        userId: z.number(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db.insert(activityLog).values({
        type: input.type,
        action: input.action,
        details: input.details || {},
        status: input.status,
        userId: input.userId,
      });
      return result;
    }),

  recent: publicQuery
    .input(z.object({ hours: z.number().default(24) }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      const hours = input?.hours || 24;
      const since = new Date(Date.now() - hours * 60 * 60 * 1000);
      
      return db.select().from(activityLog)
        .where(gte(activityLog.createdAt, since))
        .orderBy(desc(activityLog.createdAt))
        .limit(20);
    }),
});
