import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  json,
  int,
  bigint,
  time,
  boolean,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const agentConfigs = mysqlTable("agent_configs", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  agentName: varchar("agentName", { length: 100 }).default("Nexus-1"),
  autonomyLevel: mysqlEnum("autonomyLevel", ["manual", "assisted", "autonomous"]).default("autonomous"),
  dailyTaskLimit: int("dailyTaskLimit").default(50),
  workingHoursStart: time("workingHoursStart").default("09:00:00"),
  workingHoursEnd: time("workingHoursEnd").default("18:00:00"),
  timezone: varchar("timezone", { length: 50 }).default("UTC"),
  language: varchar("language", { length: 10 }).default("en"),
  isActive: boolean("isActive").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
});

export type AgentConfig = typeof agentConfigs.$inferSelect;

export const integrations = mysqlTable("integrations", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  service: mysqlEnum("service", ["gmail", "outlook", "calendar", "slack", "crm", "github"]).notNull(),
  status: mysqlEnum("status", ["connected", "disconnected", "error"]).default("disconnected"),
  config: json("config"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
});

export type Integration = typeof integrations.$inferSelect;

export const contacts = mysqlTable("contacts", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 255 }),
  phone: varchar("phone", { length: 50 }),
  company: varchar("company", { length: 255 }),
  role: varchar("role", { length: 100 }),
  category: mysqlEnum("category", ["client", "lead", "team", "vendor", "other"]).default("other"),
  tags: json("tags"),
  notes: text("notes"),
  lastContacted: timestamp("lastContacted"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
});

export type Contact = typeof contacts.$inferSelect;

export const tasks = mysqlTable("tasks", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  title: varchar("title", { length: 500 }).notNull(),
  description: text("description"),
  status: mysqlEnum("status", ["backlog", "in_progress", "review", "done", "failed"]).default("backlog"),
  priority: mysqlEnum("priority", ["low", "medium", "high", "urgent"]).default("medium"),
  assignee: varchar("assignee", { length: 255 }),
  dueDate: timestamp("dueDate"),
  tags: json("tags"),
  subtasks: json("subtasks"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
});

export type Task = typeof tasks.$inferSelect;

export const emails = mysqlTable("emails", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  fromEmail: varchar("fromEmail", { length: 255 }),
  toEmails: json("toEmails"),
  ccEmails: json("ccEmails"),
  bccEmails: json("bccEmails"),
  subject: varchar("subject", { length: 500 }),
  body: text("body"),
  bodyHtml: text("bodyHtml"),
  status: mysqlEnum("status", ["draft", "scheduled", "sent", "failed"]).default("draft"),
  template: varchar("template", { length: 100 }),
  scheduledAt: timestamp("scheduledAt"),
  sentAt: timestamp("sentAt"),
  tracking: json("tracking"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Email = typeof emails.$inferSelect;

export const calls = mysqlTable("calls", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  contactId: bigint("contactId", { mode: "number", unsigned: true }),
  title: varchar("title", { length: 255 }).notNull(),
  purpose: text("purpose"),
  scheduledAt: timestamp("scheduledAt"),
  duration: int("duration"),
  status: mysqlEnum("status", ["scheduled", "in_progress", "completed", "cancelled", "no_answer"]).default("scheduled"),
  notes: text("notes"),
  outcome: mysqlEnum("outcome", ["successful", "follow_up_needed", "no_answer", "voicemail"]),
  recordingUrl: varchar("recordingUrl", { length: 500 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Call = typeof calls.$inferSelect;

export const jobs = mysqlTable("jobs", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  title: varchar("title", { length: 500 }).notNull(),
  company: varchar("company", { length: 255 }),
  source: mysqlEnum("source", ["upwork", "linkedin", "indeed", "freelancer", "other"]).default("other"),
  sourceUrl: varchar("sourceUrl", { length: 500 }),
  description: text("description"),
  requirements: text("requirements"),
  budget: varchar("budget", { length: 100 }),
  budgetType: mysqlEnum("budgetType", ["hourly", "fixed"]).default("hourly"),
  skills: json("skills"),
  status: mysqlEnum("status", ["new", "saved", "applied", "viewed", "interview", "rejected", "hired"]).default("new"),
  proposal: text("proposal"),
  appliedAt: timestamp("appliedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Job = typeof jobs.$inferSelect;

export const codeProjects = mysqlTable("code_projects", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  language: varchar("language", { length: 50 }),
  framework: varchar("framework", { length: 50 }),
  description: text("description"),
  files: json("files"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
});

export type CodeProject = typeof codeProjects.$inferSelect;

export const activityLog = mysqlTable("activity_log", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  type: mysqlEnum("type", ["task", "email", "call", "code", "job", "system"]).notNull(),
  action: varchar("action", { length: 255 }).notNull(),
  details: json("details"),
  status: mysqlEnum("status", ["success", "warning", "error", "info"]).default("info"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ActivityLog = typeof activityLog.$inferSelect;

export const apiKeys = mysqlTable("api_keys", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  keyHash: varchar("keyHash", { length: 255 }).notNull(),
  keyMask: varchar("keyMask", { length: 50 }),
  lastUsed: timestamp("lastUsed"),
  usageCount: int("usageCount").default(0),
  isActive: boolean("isActive").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ApiKey = typeof apiKeys.$inferSelect;
