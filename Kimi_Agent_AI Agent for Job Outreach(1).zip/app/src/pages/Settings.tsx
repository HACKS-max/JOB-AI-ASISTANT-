import { useState } from "react";
import { useAppStore } from "@/store/appStore";
import {
  Settings as SettingsIcon,
  Bot,
  Link2,
  Key,
  Mail,
  Bell,
  Save,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Plus,
  Trash2,
} from "lucide-react";
import { cn } from "@/lib/utils";

const tabs = [
  { id: "general", label: "General", icon: SettingsIcon },
  { id: "agent", label: "Agent Config", icon: Bot },
  { id: "integrations", label: "Integrations", icon: Link2 },
  { id: "apikeys", label: "API Keys", icon: Key },
  { id: "email", label: "Email Settings", icon: Mail },
  { id: "notifications", label: "Notifications", icon: Bell },
];

const integrationsList = [
  { id: "gmail", name: "Gmail", description: "Send and receive emails", status: "connected", icon: Mail },
  { id: "outlook", name: "Outlook", description: "Microsoft email integration", status: "disconnected", icon: Mail },
  { id: "calendar", name: "Google Calendar", description: "Schedule meetings and calls", status: "connected", icon: Link2 },
  { id: "slack", name: "Slack", description: "Team notifications", status: "connected", icon: Link2 },
  { id: "crm", name: "HubSpot CRM", description: "Contact and deal management", status: "disconnected", icon: Link2 },
  { id: "github", name: "GitHub", description: "Code repository access", status: "connected", icon: Link2 },
];

const sampleApiKeys = [
  { id: 1, name: "Production API Key", mask: "sk-...7a9f", lastUsed: "2 hours ago", usageCount: 1247, isActive: true },
  { id: 2, name: "Development Key", mask: "sk-...3e2b", lastUsed: "5 days ago", usageCount: 89, isActive: true },
  { id: 3, name: "Test Environment", mask: "sk-...1c4d", lastUsed: "2 weeks ago", usageCount: 12, isActive: false },
];

export default function Settings() {
  const { addToast } = useAppStore();
  const [activeTab, setActiveTab] = useState("general");
  const [showNewKey, setShowNewKey] = useState(false);

  const [agentConfig, setAgentConfig] = useState({
    agentName: "Nexus-1",
    autonomyLevel: "autonomous" as string,
    dailyTaskLimit: 50,
    workingHoursStart: "09:00",
    workingHoursEnd: "18:00",
    timezone: "UTC",
    language: "en",
  });

  const [newKeyName, setNewKeyName] = useState("");

  const handleSaveAgentConfig = () => {
    addToast("success", "Agent configuration saved");
  };

  const handleCreateKey = () => {
    if (!newKeyName.trim()) {
      addToast("error", "Please enter a key name");
      return;
    }
    setShowNewKey(false);
    setNewKeyName("");
    addToast("success", "New API key created");
  };

  const statusIcon = (status: string) => {
    switch (status) {
      case "connected": return <CheckCircle2 className="w-4 h-4 text-emerald-400" />;
      case "disconnected": return <XCircle className="w-4 h-4 text-[#4A5570]" />;
      case "error": return <AlertTriangle className="w-4 h-4 text-[#FFB800]" />;
      default: return null;
    }
  };

  return (
    <div className="h-[calc(100vh-64px)] flex">
      {/* Settings Sidebar */}
      <div className="w-56 bg-[#0a0f1c] border-r border-white/[0.06] py-4">
        <div className="px-4 mb-4">
          <h3 className="text-xs font-semibold text-[#4A5570] uppercase tracking-wider">Settings</h3>
        </div>
        <nav className="space-y-1 px-2">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors",
                activeTab === tab.id
                  ? "bg-[#00D4FF]/10 text-[#00D4FF]"
                  : "text-[#7A8BA9] hover:text-white hover:bg-white/[0.04]"
              )}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </nav>
      </div>

      {/* Settings Content */}
      <div className="flex-1 overflow-y-auto p-6 scrollbar-thin">
        {/* General Tab */}
        {activeTab === "general" && (
          <div className="max-w-2xl space-y-6">
            <div>
              <h2 className="text-lg font-semibold text-white mb-1">General Settings</h2>
              <p className="text-sm text-[#4A5570]">Configure basic platform preferences</p>
            </div>
            <div className="glass rounded-2xl p-6 space-y-6">
              <div>
                <label className="block text-xs text-[#7A8BA9] uppercase tracking-wider mb-2">Agent Name</label>
                <input
                  type="text"
                  value={agentConfig.agentName}
                  onChange={(e) => setAgentConfig({ ...agentConfig, agentName: e.target.value })}
                  className="w-full h-10 px-4 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white focus:outline-none focus:border-[#00D4FF]/40"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-[#7A8BA9] uppercase tracking-wider mb-2">Timezone</label>
                  <select
                    value={agentConfig.timezone}
                    onChange={(e) => setAgentConfig({ ...agentConfig, timezone: e.target.value })}
                    className="w-full h-10 px-4 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white focus:outline-none focus:border-[#00D4FF]/40"
                  >
                    <option value="UTC">UTC</option>
                    <option value="America/New_York">Eastern Time</option>
                    <option value="America/Chicago">Central Time</option>
                    <option value="America/Denver">Mountain Time</option>
                    <option value="America/Los_Angeles">Pacific Time</option>
                    <option value="Europe/London">London</option>
                    <option value="Asia/Tokyo">Tokyo</option>
                    <option value="Asia/Karachi">Karachi (PKT)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[#7A8BA9] uppercase tracking-wider mb-2">Language</label>
                  <select
                    value={agentConfig.language}
                    onChange={(e) => setAgentConfig({ ...agentConfig, language: e.target.value })}
                    className="w-full h-10 px-4 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white focus:outline-none focus:border-[#00D4FF]/40"
                  >
                    <option value="en">English</option>
                    <option value="es">Spanish</option>
                    <option value="fr">French</option>
                    <option value="de">German</option>
                    <option value="ur">Urdu</option>
                  </select>
                </div>
              </div>
              <button
                onClick={() => addToast("success", "Settings saved")}
                className="flex items-center gap-2 h-10 px-6 gradient-accent text-white text-sm font-medium rounded-lg hover:opacity-90 transition-opacity"
              >
                <Save className="w-4 h-4" />
                Save Changes
              </button>
            </div>
          </div>
        )}

        {/* Agent Config Tab */}
        {activeTab === "agent" && (
          <div className="max-w-2xl space-y-6">
            <div>
              <h2 className="text-lg font-semibold text-white mb-1">Agent Configuration</h2>
              <p className="text-sm text-[#4A5570]">Control your AI agent&apos;s behavior and autonomy</p>
            </div>
            <div className="glass rounded-2xl p-6 space-y-6">
              <div>
                <label className="block text-xs text-[#7A8BA9] uppercase tracking-wider mb-2">Autonomy Level</label>
                <div className="flex items-center gap-1 bg-[#0D1320] rounded-lg p-1">
                  {["manual", "assisted", "autonomous"].map((level) => (
                    <button
                      key={level}
                      onClick={() => setAgentConfig({ ...agentConfig, autonomyLevel: level })}
                      className={cn(
                        "flex-1 py-2 rounded-md text-sm capitalize transition-colors",
                        agentConfig.autonomyLevel === level
                          ? "bg-[#00D4FF]/20 text-[#00D4FF]"
                          : "text-[#7A8BA9] hover:text-white"
                      )}
                    >
                      {level}
                    </button>
                  ))}
                </div>
                <p className="text-xs text-[#4A5570] mt-2">
                  {agentConfig.autonomyLevel === "autonomous"
                    ? "Agent acts independently, making decisions without approval."
                    : agentConfig.autonomyLevel === "assisted"
                    ? "Agent suggests actions but waits for your approval."
                    : "Agent only acts on explicit commands."}
                </p>
              </div>
              <div>
                <label className="block text-xs text-[#7A8BA9] uppercase tracking-wider mb-2">
                  Daily Task Limit: {agentConfig.dailyTaskLimit}
                </label>
                <input
                  type="range"
                  min={1}
                  max={200}
                  value={agentConfig.dailyTaskLimit}
                  onChange={(e) => setAgentConfig({ ...agentConfig, dailyTaskLimit: parseInt(e.target.value) })}
                  className="w-full h-2 bg-[#0D1320] rounded-full appearance-none cursor-pointer accent-[#00D4FF]"
                />
                <div className="flex justify-between text-xs text-[#4A5570] mt-1">
                  <span>1</span>
                  <span>100</span>
                  <span>200</span>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-[#7A8BA9] uppercase tracking-wider mb-2">Working Hours Start</label>
                  <input
                    type="time"
                    value={agentConfig.workingHoursStart}
                    onChange={(e) => setAgentConfig({ ...agentConfig, workingHoursStart: e.target.value })}
                    className="w-full h-10 px-4 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white focus:outline-none focus:border-[#00D4FF]/40"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[#7A8BA9] uppercase tracking-wider mb-2">Working Hours End</label>
                  <input
                    type="time"
                    value={agentConfig.workingHoursEnd}
                    onChange={(e) => setAgentConfig({ ...agentConfig, workingHoursEnd: e.target.value })}
                    className="w-full h-10 px-4 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white focus:outline-none focus:border-[#00D4FF]/40"
                  />
                </div>
              </div>
              <button
                onClick={handleSaveAgentConfig}
                className="flex items-center gap-2 h-10 px-6 gradient-accent text-white text-sm font-medium rounded-lg hover:opacity-90 transition-opacity"
              >
                <Save className="w-4 h-4" />
                Save Configuration
              </button>
            </div>
          </div>
        )}

        {/* Integrations Tab */}
        {activeTab === "integrations" && (
          <div className="max-w-3xl space-y-6">
            <div>
              <h2 className="text-lg font-semibold text-white mb-1">Integrations</h2>
              <p className="text-sm text-[#4A5570]">Connect your tools and services</p>
            </div>
            <div className="space-y-3">
              {integrationsList.map((integration) => (
                <div key={integration.id} className="glass rounded-xl p-4 flex items-center justify-between card-hover">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-[#0D1320] flex items-center justify-center">
                      <integration.icon className="w-5 h-5 text-[#00D4FF]" />
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-white">{integration.name}</h4>
                      <p className="text-xs text-[#7A8BA9]">{integration.description}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1.5">
                      {statusIcon(integration.status)}
                      <span className={cn(
                        "text-xs capitalize",
                        integration.status === "connected" ? "text-emerald-400" : "text-[#4A5570]"
                      )}>
                        {integration.status}
                      </span>
                    </div>
                    <button
                      className={cn(
                        "h-8 px-3 text-xs rounded-lg transition-colors",
                        integration.status === "connected"
                          ? "bg-red-400/10 text-red-400 hover:bg-red-400/20"
                          : "gradient-accent text-white hover:opacity-90"
                      )}
                    >
                      {integration.status === "connected" ? "Disconnect" : "Connect"}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* API Keys Tab */}
        {activeTab === "apikeys" && (
          <div className="max-w-3xl space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-semibold text-white mb-1">API Keys</h2>
                <p className="text-sm text-[#4A5570]">Manage your API keys for external access</p>
              </div>
              <button
                onClick={() => setShowNewKey(true)}
                className="flex items-center gap-2 h-10 px-4 gradient-accent text-white text-sm font-medium rounded-lg hover:opacity-90 transition-opacity"
              >
                <Plus className="w-4 h-4" />
                New Key
              </button>
            </div>

            {showNewKey && (
              <div className="glass rounded-xl p-4 space-y-3">
                <div className="flex items-center gap-3">
                  <input
                    type="text"
                    placeholder="Key name (e.g., Production)"
                    value={newKeyName}
                    onChange={(e) => setNewKeyName(e.target.value)}
                    className="flex-1 h-10 px-4 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white placeholder-[#4A5570] focus:outline-none focus:border-[#00D4FF]/40"
                  />
                  <button
                    onClick={handleCreateKey}
                    className="h-10 px-4 gradient-accent text-white text-sm font-medium rounded-lg hover:opacity-90 transition-opacity"
                  >
                    Create
                  </button>
                  <button
                    onClick={() => setShowNewKey(false)}
                    className="h-10 px-4 bg-[#0D1320] border border-white/[0.08] text-[#7A8BA9] text-sm rounded-lg hover:text-white transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}

            <div className="space-y-3">
              {sampleApiKeys.map((key) => (
                <div key={key.id} className="glass rounded-xl p-4 flex items-center justify-between card-hover">
                  <div>
                    <h4 className="text-sm font-medium text-white">{key.name}</h4>
                    <div className="flex items-center gap-3 mt-1 text-xs text-[#4A5570]">
                      <span className="font-mono">{key.mask}</span>
                      <span>Last used: {key.lastUsed}</span>
                      <span>{key.usageCount.toLocaleString()} requests</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={cn(
                      "text-xs px-2 py-0.5 rounded-full",
                      key.isActive ? "bg-emerald-400/20 text-emerald-400" : "bg-[#7A8BA9]/20 text-[#7A8BA9]"
                    )}>
                      {key.isActive ? "Active" : "Inactive"}
                    </span>
                    <button className="p-2 text-[#4A5570] hover:text-red-400 hover:bg-red-400/10 rounded-lg transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Email Settings Tab */}
        {activeTab === "email" && (
          <div className="max-w-2xl space-y-6">
            <div>
              <h2 className="text-lg font-semibold text-white mb-1">Email Settings</h2>
              <p className="text-sm text-[#4A5570]">Configure email behavior and defaults</p>
            </div>
            <div className="glass rounded-2xl p-6 space-y-6">
              <div>
                <label className="block text-xs text-[#7A8BA9] uppercase tracking-wider mb-2">Default From Address</label>
                <input
                  type="email"
                  placeholder="agent@yourcompany.com"
                  className="w-full h-10 px-4 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white placeholder-[#4A5570] focus:outline-none focus:border-[#00D4FF]/40"
                />
              </div>
              <div>
                <label className="block text-xs text-[#7A8BA9] uppercase tracking-wider mb-2">Email Signature</label>
                <textarea
                  rows={4}
                  placeholder="Best regards,\nNexusAI Agent"
                  className="w-full px-4 py-3 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white placeholder-[#4A5570] focus:outline-none focus:border-[#00D4FF]/40 resize-none"
                />
              </div>
              <div className="flex items-center justify-between py-3 border-t border-white/[0.06]">
                <div>
                  <p className="text-sm text-white">Track Email Opens</p>
                  <p className="text-xs text-[#4A5570]">Get notified when recipients open your emails</p>
                </div>
                <button className="w-12 h-6 bg-[#00D4FF] rounded-full relative">
                  <span className="absolute right-0.5 top-0.5 w-5 h-5 bg-white rounded-full shadow" />
                </button>
              </div>
              <div className="flex items-center justify-between py-3 border-t border-white/[0.06]">
                <div>
                  <p className="text-sm text-white">Track Link Clicks</p>
                  <p className="text-xs text-[#4A5570]">Monitor which links are clicked in your emails</p>
                </div>
                <button className="w-12 h-6 bg-[#00D4FF] rounded-full relative">
                  <span className="absolute right-0.5 top-0.5 w-5 h-5 bg-white rounded-full shadow" />
                </button>
              </div>
              <button
                onClick={() => addToast("success", "Email settings saved")}
                className="flex items-center gap-2 h-10 px-6 gradient-accent text-white text-sm font-medium rounded-lg hover:opacity-90 transition-opacity"
              >
                <Save className="w-4 h-4" />
                Save Settings
              </button>
            </div>
          </div>
        )}

        {/* Notifications Tab */}
        {activeTab === "notifications" && (
          <div className="max-w-2xl space-y-6">
            <div>
              <h2 className="text-lg font-semibold text-white mb-1">Notifications</h2>
              <p className="text-sm text-[#4A5570]">Choose what you want to be notified about</p>
            </div>
            <div className="glass rounded-2xl p-6 space-y-4">
              {[
                { label: "Task Completed", desc: "Get notified when a task is completed", default: true },
                { label: "Email Sent", desc: "Notification when emails are sent", default: true },
                { label: "Call Scheduled", desc: "Reminder for upcoming calls", default: true },
                { label: "Job Application", desc: "Status updates on job applications", default: false },
                { label: "Code Generated", desc: "When new code is generated", default: false },
                { label: "System Errors", desc: "Critical system notifications", default: true },
              ].map((item) => (
                <div key={item.label} className="flex items-center justify-between py-3 border-b border-white/[0.04]">
                  <div>
                    <p className="text-sm text-white">{item.label}</p>
                    <p className="text-xs text-[#4A5570]">{item.desc}</p>
                  </div>
                  <button className={cn(
                    "w-12 h-6 rounded-full relative transition-colors",
                    item.default ? "bg-[#00D4FF]" : "bg-[#0D1320] border border-white/[0.1]"
                  )}>
                    <span className={cn(
                      "absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-all",
                      item.default ? "right-0.5" : "left-0.5"
                    )} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
