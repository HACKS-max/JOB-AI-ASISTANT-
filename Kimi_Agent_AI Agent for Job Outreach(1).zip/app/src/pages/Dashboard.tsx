import { useAppStore } from "@/store/appStore";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import {
  CheckSquare,
  Mail,
  Phone,
  Briefcase,
  ArrowUpRight,
  ArrowDownRight,
  Terminal,
  Clock,
  Zap,
} from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { cn } from "@/lib/utils";

const activityData = [
  { time: "00:00", tasks: 4, emails: 12, calls: 2 },
  { time: "04:00", tasks: 2, emails: 8, calls: 0 },
  { time: "08:00", tasks: 8, emails: 24, calls: 5 },
  { time: "12:00", tasks: 12, emails: 32, calls: 8 },
  { time: "16:00", tasks: 6, emails: 18, calls: 3 },
  { time: "20:00", tasks: 3, emails: 10, calls: 1 },
];

const taskDistribution = [
  { name: "Backlog", value: 8, color: "#7A8BA9" },
  { name: "In Progress", value: 12, color: "#00D4FF" },
  { name: "Review", value: 5, color: "#7B61FF" },
  { name: "Done", value: 24, color: "#00E396" },
];

const recentActivities = [
  { id: 1, type: "email", action: "Sent onboarding email to 24 leads", status: "success", time: "2 min ago" },
  { id: 2, type: "task", action: "Completed: Generate landing page component", status: "success", time: "5 min ago" },
  { id: 3, type: "call", action: "Scheduled call with Acme Corp", status: "success", time: "12 min ago" },
  { id: 4, type: "job", action: "Applied to 3 frontend positions", status: "success", time: "18 min ago" },
  { id: 5, type: "code", action: "Generated React contact form with validation", status: "success", time: "25 min ago" },
  { id: 6, type: "system", action: "Integration error: Gmail API rate limit", status: "warning", time: "30 min ago" },
  { id: 7, type: "email", action: "Failed to send: Invalid recipient address", status: "error", time: "35 min ago" },
  { id: 8, type: "task", action: "Started: Update CRM with new contacts", status: "info", time: "40 min ago" },
];

const quickActions = [
  { id: "task", label: "Create Task", icon: CheckSquare, color: "#00D4FF" },
  { id: "email", label: "Send Email", icon: Mail, color: "#7B61FF" },
  { id: "call", label: "Schedule Call", icon: Phone, color: "#00E396" },
  { id: "code", label: "Generate Code", icon: Zap, color: "#FFB800" },
  { id: "job", label: "Find Jobs", icon: Briefcase, color: "#FF4560" },
];

export default function Dashboard() {
  const { openModal } = useAppStore();
  const { user } = useAuth();

  const { data: taskStats } = trpc.task.stats.useQuery();
  const { data: emailStats } = trpc.email.stats.useQuery();
  const { data: callStats } = trpc.call.stats.useQuery();
  const { data: jobStats } = trpc.job.stats.useQuery();

  const stats = [
    {
      label: "Active Tasks",
      value: taskStats?.inProgress || 0,
      total: taskStats?.total || 0,
      icon: CheckSquare,
      color: "#00D4FF",
      trend: "+12%",
      trendUp: true,
    },
    {
      label: "Emails Sent",
      value: emailStats?.sent || 0,
      total: emailStats?.total || 0,
      icon: Mail,
      color: "#7B61FF",
      trend: "+8%",
      trendUp: true,
    },
    {
      label: "Calls Today",
      value: callStats?.scheduled || 0,
      total: callStats?.total || 0,
      icon: Phone,
      color: "#00E396",
      trend: "+5%",
      trendUp: true,
    },
    {
      label: "Jobs Applied",
      value: jobStats?.applied || 0,
      total: jobStats?.total || 0,
      icon: Briefcase,
      color: "#FFB800",
      trend: "+15%",
      trendUp: true,
    },
  ];

  const getActivityIcon = (type: string, status: string) => {
    const icons: Record<string, typeof Terminal> = {
      task: CheckSquare,
      email: Mail,
      call: Phone,
      code: Zap,
      job: Briefcase,
      system: Terminal,
    };
    const Icon = icons[type] || Terminal;
    const statusColors: Record<string, string> = {
      success: "text-emerald-400 bg-emerald-400/10",
      warning: "text-amber-400 bg-amber-400/10",
      error: "text-red-400 bg-red-400/10",
      info: "text-sky-400 bg-sky-400/10",
    };
    return { Icon, colorClass: statusColors[status] || statusColors.info };
  };

  return (
    <div className="p-6 space-y-6">
      {/* Welcome Banner */}
      <div className="glass rounded-2xl p-6 flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">
            Welcome back, {user?.name?.split(" ")[0] || "Commander"}
          </h2>
          <p className="text-sm text-[#7A8BA9] mt-1">
            Your AI agent has been working autonomously. Here&apos;s what&apos;s happening.
          </p>
        </div>
        <div className="hidden md:flex items-center gap-2 px-4 py-2 bg-emerald-400/10 rounded-full">
          <span className="w-2 h-2 rounded-full bg-emerald-400 status-pulse" />
          <span className="text-sm text-emerald-400 font-medium">All Systems Operational</span>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <div
            key={stat.label}
            className="glass rounded-2xl p-5 card-hover cursor-pointer"
          >
            <div className="flex items-start justify-between">
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{ backgroundColor: `${stat.color}15` }}
              >
                <stat.icon className="w-5 h-5" style={{ color: stat.color }} />
              </div>
              <div className="flex items-center gap-1 text-xs">
                {stat.trendUp ? (
                  <ArrowUpRight className="w-3 h-3 text-emerald-400" />
                ) : (
                  <ArrowDownRight className="w-3 h-3 text-red-400" />
                )}
                <span className={stat.trendUp ? "text-emerald-400" : "text-red-400"}>
                  {stat.trend}
                </span>
              </div>
            </div>
            <div className="mt-4">
              <p className="text-2xl font-bold text-white">{stat.value}</p>
              <p className="text-xs text-[#4A5570] mt-0.5">
                {stat.label} of {stat.total} total
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Agent Activity & Charts */}
        <div className="lg:col-span-2 space-y-6">
          {/* Activity Chart */}
          <div className="glass rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-white">Activity Overview</h3>
                <p className="text-xs text-[#4A5570]">Last 24 hours</p>
              </div>
              <div className="flex items-center gap-4 text-xs">
                <span className="flex items-center gap-1.5 text-[#7A8BA9]">
                  <span className="w-2 h-2 rounded-full bg-[#00D4FF]" />
                  Tasks
                </span>
                <span className="flex items-center gap-1.5 text-[#7A8BA9]">
                  <span className="w-2 h-2 rounded-full bg-[#7B61FF]" />
                  Emails
                </span>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={240}>
              <AreaChart data={activityData}>
                <defs>
                  <linearGradient id="colorTasks" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00D4FF" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#00D4FF" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorEmails" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#7B61FF" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#7B61FF" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                <XAxis dataKey="time" stroke="#4A5570" fontSize={11} />
                <YAxis stroke="#4A5570" fontSize={11} />
                <Tooltip
                  contentStyle={{
                    background: "rgba(13,19,32,0.95)",
                    border: "1px solid rgba(255,255,255,0.1)",
                    borderRadius: "8px",
                  }}
                />
                <Area type="monotone" dataKey="tasks" stroke="#00D4FF" fill="url(#colorTasks)" strokeWidth={2} />
                <Area type="monotone" dataKey="emails" stroke="#7B61FF" fill="url(#colorEmails)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Task Distribution */}
          <div className="glass rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-6">Task Distribution</h3>
            <div className="flex items-center gap-8">
              <ResponsiveContainer width={180} height={180}>
                <PieChart>
                  <Pie
                    data={taskDistribution}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={85}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {taskDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      background: "rgba(13,19,32,0.95)",
                      border: "1px solid rgba(255,255,255,0.1)",
                      borderRadius: "8px",
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
              <div className="flex-1 space-y-3">
                {taskDistribution.map((item) => (
                  <div key={item.name} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                      <span className="text-sm text-[#7A8BA9]">{item.name}</span>
                    </div>
                    <span className="text-sm font-semibold text-white">{item.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right Panel: Quick Actions + Activity */}
        <div className="space-y-6">
          {/* Quick Actions */}
          <div className="glass rounded-2xl p-6">
            <h3 className="text-sm font-semibold text-white mb-4 uppercase tracking-wider">Quick Actions</h3>
            <div className="space-y-2">
              {quickActions.map((action) => (
                <button
                  key={action.id}
                  onClick={() => openModal(`quick-${action.id}`)}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-[#0D1320] border border-white/[0.06] hover:border-white/[0.12] transition-all group"
                >
                  <div
                    className="w-8 h-8 rounded-lg flex items-center justify-center"
                    style={{ backgroundColor: `${action.color}15` }}
                  >
                    <action.icon className="w-4 h-4" style={{ color: action.color }} />
                  </div>
                  <span className="text-sm text-white group-hover:text-[#00D4FF] transition-colors">
                    {action.label}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Live Activity Feed */}
          <div className="glass rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-white uppercase tracking-wider">Live Activity</h3>
              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 status-pulse" />
                <span className="text-xs text-emerald-400">Live</span>
              </div>
            </div>
            <div className="space-y-3 max-h-[400px] overflow-y-auto scrollbar-thin pr-1">
              {recentActivities.map((activity) => {
                const { Icon, colorClass } = getActivityIcon(activity.type, activity.status);
                return (
                  <div key={activity.id} className="flex items-start gap-3 group">
                    <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0", colorClass)}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm text-white/90 leading-snug">{activity.action}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Clock className="w-3 h-3 text-[#4A5570]" />
                        <span className="text-xs text-[#4A5570]">{activity.time}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Agent Status Card */}
          <div className="glass rounded-2xl p-6">
            <h3 className="text-sm font-semibold text-white mb-4 uppercase tracking-wider">Agent Health</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-[#7A8BA9]">CPU Usage</span>
                <span className="text-sm text-white font-medium">34%</span>
              </div>
              <div className="h-1.5 bg-[#0D1320] rounded-full overflow-hidden">
                <div className="h-full gradient-accent rounded-full" style={{ width: "34%" }} />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-[#7A8BA9]">Memory</span>
                <span className="text-sm text-white font-medium">62%</span>
              </div>
              <div className="h-1.5 bg-[#0D1320] rounded-full overflow-hidden">
                <div className="h-full bg-[#7B61FF] rounded-full" style={{ width: "62%" }} />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-[#7A8BA9]">Queue</span>
                <span className="text-sm text-white font-medium">12 tasks</span>
              </div>
              <div className="h-1.5 bg-[#0D1320] rounded-full overflow-hidden">
                <div className="h-full bg-[#FFB800] rounded-full" style={{ width: "45%" }} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
