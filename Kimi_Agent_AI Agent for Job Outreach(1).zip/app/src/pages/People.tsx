import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { useAppStore } from "@/store/appStore";
import {
  Users,
  Plus,
  Search,
  Mail,
  Phone,
  Building2,
  Calendar,
  FileText,
  Trash2,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { format } from "date-fns";

const categoryColors: Record<string, string> = {
  client: "bg-[#00D4FF]/20 text-[#00D4FF]",
  lead: "bg-[#FFB800]/20 text-[#FFB800]",
  team: "bg-[#00E396]/20 text-[#00E396]",
  vendor: "bg-[#7B61FF]/20 text-[#7B61FF]",
  other: "bg-[#7A8BA9]/20 text-[#7A8BA9]",
};

const categoryOptions = [
  { value: "client", label: "Client" },
  { value: "lead", label: "Lead" },
  { value: "team", label: "Team" },
  { value: "vendor", label: "Vendor" },
  { value: "other", label: "Other" },
];

export default function People() {
  const { addToast } = useAppStore();
  const [activeCategory, setActiveCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [selectedContact, setSelectedContact] = useState<any>(null);

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    role: "",
    category: "other" as string,
    tags: "" as string,
    notes: "",
  });

  const utils = trpc.useUtils();
  const { data: contacts } = trpc.contact.list.useQuery({
    category: activeCategory !== "all" ? activeCategory : undefined,
    search: searchQuery || undefined,
  });

  const createContact = trpc.contact.create.useMutation({
    onSuccess: () => {
      utils.contact.list.invalidate();
      utils.contact.stats.invalidate();
      setShowCreate(false);
      setFormData({ name: "", email: "", phone: "", company: "", role: "", category: "other", tags: "", notes: "" });
      addToast("success", "Contact added successfully");
    },
  });

  const deleteContact = trpc.contact.delete.useMutation({
    onSuccess: () => {
      utils.contact.list.invalidate();
      setSelectedContact(null);
      addToast("success", "Contact deleted");
    },
  });

  const handleCreate = () => {
    if (!formData.name) {
      addToast("error", "Name is required");
      return;
    }
    createContact.mutate({
      ...formData,
      tags: formData.tags ? formData.tags.split(",").map((t) => t.trim()) : [],
      userId: 1,
    });
  };

  const getInitials = (name: string) => {
    return name.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2);
  };

  const getAvatarColor = (name: string) => {
    const colors = ["#00D4FF", "#7B61FF", "#00E396", "#FFB800", "#FF4560"];
    const index = name.charCodeAt(0) % colors.length;
    return colors[index];
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2 bg-[#0D1320] rounded-lg p-1 border border-white/[0.06]">
          {["all", ...categoryOptions.map((c) => c.value)].map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={cn(
                "px-3 py-1.5 rounded-md text-sm capitalize transition-colors",
                activeCategory === cat ? "bg-[#00D4FF]/20 text-[#00D4FF]" : "text-[#7A8BA9] hover:text-white"
              )}
            >
              {cat}
            </button>
          ))}
        </div>
        <button
          onClick={() => setShowCreate(true)}
          className="flex items-center gap-2 h-10 px-5 gradient-accent text-white text-sm font-medium rounded-full hover:opacity-90 transition-opacity"
        >
          <Plus className="w-4 h-4" />
          Add Contact
        </button>
      </div>

      {/* Search */}
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#4A5570]" />
        <input
          type="text"
          placeholder="Search contacts..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full h-10 pl-10 pr-4 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white placeholder-[#4A5570] focus:outline-none focus:border-[#00D4FF]/40 transition-all"
        />
      </div>

      {/* Create Contact Modal */}
      {showCreate && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="glass-strong rounded-2xl p-6 w-full max-w-md animate-slide-in">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-white">Add Contact</h3>
              <button onClick={() => setShowCreate(false)} className="text-[#4A5570] hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-4">
              <input
                type="text"
                placeholder="Full Name *"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full h-10 px-4 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white placeholder-[#4A5570] focus:outline-none focus:border-[#00D4FF]/40"
              />
              <div className="grid grid-cols-2 gap-4">
                <input
                  type="email"
                  placeholder="Email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full h-10 px-4 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white placeholder-[#4A5570] focus:outline-none focus:border-[#00D4FF]/40"
                />
                <input
                  type="tel"
                  placeholder="Phone"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full h-10 px-4 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white placeholder-[#4A5570] focus:outline-none focus:border-[#00D4FF]/40"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="Company"
                  value={formData.company}
                  onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                  className="w-full h-10 px-4 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white placeholder-[#4A5570] focus:outline-none focus:border-[#00D4FF]/40"
                />
                <input
                  type="text"
                  placeholder="Role"
                  value={formData.role}
                  onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                  className="w-full h-10 px-4 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white placeholder-[#4A5570] focus:outline-none focus:border-[#00D4FF]/40"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  className="w-full h-10 px-4 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white focus:outline-none focus:border-[#00D4FF]/40"
                >
                  {categoryOptions.map((opt) => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                  ))}
                </select>
                <input
                  type="text"
                  placeholder="Tags (comma separated)"
                  value={formData.tags}
                  onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                  className="w-full h-10 px-4 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white placeholder-[#4A5570] focus:outline-none focus:border-[#00D4FF]/40"
                />
              </div>
              <textarea
                placeholder="Notes..."
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={3}
                className="w-full px-4 py-2 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white placeholder-[#4A5570] focus:outline-none focus:border-[#00D4FF]/40 resize-none"
              />
              <button
                onClick={handleCreate}
                disabled={createContact.isPending}
                className="w-full h-10 gradient-accent text-white text-sm font-medium rounded-lg hover:opacity-90 transition-opacity disabled:opacity-50"
              >
                Add Contact
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Contacts Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {contacts?.map((contact) => (
          <div
            key={contact.id}
            className="glass rounded-xl p-5 card-hover cursor-pointer"
            onClick={() => setSelectedContact(contact)}
          >
            <div className="flex items-start justify-between mb-4">
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center text-white font-semibold text-sm"
                style={{ backgroundColor: getAvatarColor(contact.name) }}
              >
                {getInitials(contact.name)}
              </div>
              <span className={cn("text-xs px-2 py-0.5 rounded-full capitalize", categoryColors[contact.category || "other"])}>
                {contact.category || "other"}
              </span>
            </div>
            <h4 className="text-sm font-semibold text-white mb-0.5">{contact.name}</h4>
            {contact.role && <p className="text-xs text-[#7A8BA9] mb-1">{contact.role}</p>}
            {contact.company && <p className="text-xs text-[#4A5570] mb-3">{contact.company}</p>}
            <div className="space-y-1.5">
              {contact.email && (
                <div className="flex items-center gap-2 text-xs text-[#7A8BA9]">
                  <Mail className="w-3 h-3" />
                  <span className="truncate">{contact.email}</span>
                </div>
              )}
              {contact.phone && (
                <div className="flex items-center gap-2 text-xs text-[#7A8BA9]">
                  <Phone className="w-3 h-3" />
                  <span>{contact.phone}</span>
                </div>
              )}
            </div>
            {contact.tags && Array.isArray(contact.tags) && (contact.tags as string[]).length > 0 && (
              <div className="flex flex-wrap gap-1 mt-3">
                {(contact.tags as string[]).map((tag: string) => (
                  <span key={tag} className="text-[10px] bg-[#0D1320] text-[#7A8BA9] px-1.5 py-0.5 rounded">
                    {tag}
                  </span>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>

      {contacts?.length === 0 && (
        <div className="flex flex-col items-center justify-center py-16 text-[#4A5570]">
          <Users className="w-12 h-12 mb-3 opacity-50" />
          <p className="text-sm">No contacts found</p>
        </div>
      )}

      {/* Contact Detail Modal */}
      {selectedContact && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="glass-strong rounded-2xl p-6 w-full max-w-md animate-slide-in">
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-center gap-4">
                <div
                  className="w-16 h-16 rounded-full flex items-center justify-center text-white font-semibold text-lg"
                  style={{ backgroundColor: getAvatarColor(selectedContact.name) }}
                >
                  {getInitials(selectedContact.name)}
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white">{selectedContact.name}</h3>
                  <p className="text-sm text-[#7A8BA9]">{selectedContact.role || "No role"}</p>
                  <span className={cn("text-xs px-2 py-0.5 rounded-full capitalize mt-1 inline-block", categoryColors[selectedContact.category || "other"])}>
                    {selectedContact.category || "other"}
                  </span>
                </div>
              </div>
              <button onClick={() => setSelectedContact(null)} className="text-[#4A5570] hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-3 mb-4">
              {selectedContact.email && (
                <div className="flex items-center gap-3 text-sm">
                  <Mail className="w-4 h-4 text-[#00D4FF]" />
                  <span className="text-white">{selectedContact.email}</span>
                </div>
              )}
              {selectedContact.phone && (
                <div className="flex items-center gap-3 text-sm">
                  <Phone className="w-4 h-4 text-[#7B61FF]" />
                  <span className="text-white">{selectedContact.phone}</span>
                </div>
              )}
              {selectedContact.company && (
                <div className="flex items-center gap-3 text-sm">
                  <Building2 className="w-4 h-4 text-[#FFB800]" />
                  <span className="text-white">{selectedContact.company}</span>
                </div>
              )}
              {selectedContact.lastContacted && (
                <div className="flex items-center gap-3 text-sm">
                  <Calendar className="w-4 h-4 text-[#7A8BA9]" />
                  <span className="text-[#7A8BA9]">
                    Last contacted: {format(new Date(selectedContact.lastContacted), "MMM d, yyyy")}
                  </span>
                </div>
              )}
            </div>
            {selectedContact.notes && (
              <div className="border-t border-white/[0.06] pt-4 mb-4">
                <div className="flex items-center gap-2 mb-2">
                  <FileText className="w-4 h-4 text-[#7A8BA9]" />
                  <span className="text-xs text-[#7A8BA9] uppercase tracking-wider">Notes</span>
                </div>
                <p className="text-sm text-[#E8ECF4]">{selectedContact.notes}</p>
              </div>
            )}
            {selectedContact.tags && Array.isArray(selectedContact.tags) && (selectedContact.tags as string[]).length > 0 && (
              <div className="flex flex-wrap gap-1.5 mb-4">
                {(selectedContact.tags as string[]).map((tag: string) => (
                  <span key={tag} className="text-xs bg-[#0D1320] text-[#00D4FF] px-2 py-1 rounded-full">
                    {tag}
                  </span>
                ))}
              </div>
            )}
            <div className="flex gap-2">
              <button className="flex-1 flex items-center justify-center gap-2 h-10 gradient-accent text-white text-sm font-medium rounded-lg hover:opacity-90 transition-opacity">
                <Mail className="w-4 h-4" />
                Send Email
              </button>
              <button className="flex items-center justify-center gap-2 h-10 px-4 bg-[#0D1320] border border-white/[0.08] text-white text-sm rounded-lg hover:bg-white/[0.04] transition-colors">
                <Phone className="w-4 h-4" />
                Call
              </button>
              <button
                onClick={() => deleteContact.mutate({ id: selectedContact.id })}
                className="flex items-center justify-center h-10 px-3 bg-red-400/10 text-red-400 rounded-lg hover:bg-red-400/20 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
