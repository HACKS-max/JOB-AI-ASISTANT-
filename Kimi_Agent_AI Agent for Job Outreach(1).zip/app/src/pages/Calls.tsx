import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { useAppStore } from "@/store/appStore";
import {
  Phone,
  Plus,
  Search,
  Calendar,
  Clock,
  CheckCircle2,
  PhoneOff,
  PhoneIncoming,
  Trash2,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { format } from "date-fns";

const tabs = [
  { id: "all", label: "All Calls" },
  { id: "scheduled", label: "Upcoming" },
  { id: "completed", label: "Completed" },
  { id: "cancelled", label: "Cancelled" },
];

export default function Calls() {
  const { addToast } = useAppStore();
  const [activeTab, setActiveTab] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [showCreate, setShowCreate] = useState(false);

  const [formData, setFormData] = useState({
    title: "",
    purpose: "",
    scheduledAt: "",
    duration: 30,
  });

  const utils = trpc.useUtils();
  const { data: calls } = trpc.call.list.useQuery({
    status: activeTab !== "all" ? activeTab : undefined,
  });

  const createCall = trpc.call.create.useMutation({
    onSuccess: () => {
      utils.call.list.invalidate();
      utils.call.stats.invalidate();
      setShowCreate(false);
      setFormData({ title: "", purpose: "", scheduledAt: "", duration: 30 });
      addToast("success", "Call scheduled successfully");
    },
  });

  const deleteCall = trpc.call.delete.useMutation({
    onSuccess: () => {
      utils.call.list.invalidate();
      addToast("success", "Call deleted");
    },
  });

  const handleCreate = () => {
    if (!formData.title || !formData.scheduledAt) {
      addToast("error", "Please fill in all required fields");
      return;
    }
    createCall.mutate({
      ...formData,
      userId: 1,
    });
  };

  const filteredCalls = calls?.filter((call) => {
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return call.title.toLowerCase().includes(q) || (call.purpose || "").toLowerCase().includes(q);
    }
    return true;
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "scheduled": return <Calendar className="w-4 h-4 text-[#FFB800]" />;
      case "in_progress": return <PhoneIncoming className="w-4 h-4 text-[#00D4FF] animate-pulse" />;
      case "completed": return <CheckCircle2 className="w-4 h-4 text-emerald-400" />;
      case "cancelled": return <PhoneOff className="w-4 h-4 text-[#7A8BA9]" />;
      default: return <Clock className="w-4 h-4 text-[#7A8BA9]" />;
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2 bg-[#0D1320] rounded-lg p-1 border border-white/[0.06]">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                "px-3 py-1.5 rounded-md text-sm transition-colors",
                activeTab === tab.id ? "bg-[#00D4FF]/20 text-[#00D4FF]" : "text-[#7A8BA9] hover:text-white"
              )}
            >
              {tab.label}
            </button>
          ))}
        </div>
        <button
          onClick={() => setShowCreate(true)}
          className="flex items-center gap-2 h-10 px-5 gradient-accent text-white text-sm font-medium rounded-full hover:opacity-90 transition-opacity"
        >
          <Plus className="w-4 h-4" />
          Schedule Call
        </button>
      </div>

      {/* Search */}
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#4A5570]" />
        <input
          type="text"
          placeholder="Search calls..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full h-10 pl-10 pr-4 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white placeholder-[#4A5570] focus:outline-none focus:border-[#00D4FF]/40 transition-all"
        />
      </div>

      {/* Create Call Modal */}
      {showCreate && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="glass-strong rounded-2xl p-6 w-full max-w-md animate-slide-in">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-white">Schedule Call</h3>
              <button onClick={() => setShowCreate(false)} className="text-[#4A5570] hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-xs text-[#7A8BA9] uppercase tracking-wider mb-1.5">Title</label>
                <input
                  type="text"
                  placeholder="e.g., Client onboarding call"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full h-10 px-4 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white placeholder-[#4A5570] focus:outline-none focus:border-[#00D4FF]/40"
                />
              </div>
              <div>
                <label className="block text-xs text-[#7A8BA9] uppercase tracking-wider mb-1.5">Purpose</label>
                <textarea
                  placeholder="What is this call about?"
                  value={formData.purpose}
                  onChange={(e) => setFormData({ ...formData, purpose: e.target.value })}
                  rows={3}
                  className="w-full px-4 py-2 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white placeholder-[#4A5570] focus:outline-none focus:border-[#00D4FF]/40 resize-none"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-[#7A8BA9] uppercase tracking-wider mb-1.5">Date & Time</label>
                  <input
                    type="datetime-local"
                    value={formData.scheduledAt}
                    onChange={(e) => setFormData({ ...formData, scheduledAt: e.target.value })}
                    className="w-full h-10 px-3 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white focus:outline-none focus:border-[#00D4FF]/40"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[#7A8BA9] uppercase tracking-wider mb-1.5">Duration (min)</label>
                  <input
                    type="number"
                    min={5}
                    max={480}
                    value={formData.duration}
                    onChange={(e) => setFormData({ ...formData, duration: parseInt(e.target.value) || 30 })}
                    className="w-full h-10 px-4 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white focus:outline-none focus:border-[#00D4FF]/40"
                  />
                </div>
              </div>
              <button
                onClick={handleCreate}
                disabled={createCall.isPending}
                className="w-full h-10 gradient-accent text-white text-sm font-medium rounded-lg hover:opacity-90 transition-opacity disabled:opacity-50"
              >
                Schedule Call
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Calls Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredCalls?.map((call) => (
          <div
            key={call.id}
            className="glass rounded-xl p-5 card-hover"
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                {getStatusIcon(call.status || "scheduled")}
                <span className={cn(
                  "text-xs px-2 py-0.5 rounded-full",
                  call.status === "scheduled" && "bg-[#FFB800]/20 text-[#FFB800]",
                  call.status === "in_progress" && "bg-[#00D4FF]/20 text-[#00D4FF]",
                  call.status === "completed" && "bg-emerald-400/20 text-emerald-400",
                  call.status === "cancelled" && "bg-[#7A8BA9]/20 text-[#7A8BA9]",
                )}>
                  {call.status || "scheduled"}
                </span>
              </div>
              <button
                onClick={() => deleteCall.mutate({ id: call.id })}
                className="text-[#4A5570] hover:text-red-400 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
            <h4 className="text-sm font-medium text-white mb-2">{call.title}</h4>
            {call.purpose && (
              <p className="text-xs text-[#7A8BA9] mb-3 line-clamp-2">{call.purpose}</p>
            )}
            <div className="space-y-1.5">
              <div className="flex items-center gap-2 text-xs text-[#7A8BA9]">
                <Calendar className="w-3.5 h-3.5" />
                <span>{call.scheduledAt ? format(new Date(call.scheduledAt), "MMM d, yyyy h:mm a") : "Not scheduled"}</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-[#7A8BA9]">
                <Clock className="w-3.5 h-3.5" />
                <span>{call.duration || 30} minutes</span>
              </div>
            </div>
            {call.status === "completed" && call.outcome && (
              <div className="mt-3 pt-3 border-t border-white/[0.06]">
                <span className="text-xs text-emerald-400">Outcome: {call.outcome.replace("_", " ")}</span>
              </div>
            )}
          </div>
        ))}
      </div>

      {filteredCalls?.length === 0 && (
        <div className="flex flex-col items-center justify-center py-16 text-[#4A5570]">
          <Phone className="w-12 h-12 mb-3 opacity-50" />
          <p className="text-sm">No calls found</p>
        </div>
      )}
    </div>
  );
}
