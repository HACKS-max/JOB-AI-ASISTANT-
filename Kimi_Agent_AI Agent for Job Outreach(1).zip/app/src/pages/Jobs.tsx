import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { useAppStore } from "@/store/appStore";
import {
  Briefcase,
  Search,
  ExternalLink,
  Bookmark,
  Send,
  DollarSign,
  Clock,
  Trash2,
  Sparkles,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { format } from "date-fns";

const sourceTabs = [
  { id: "all", label: "All Sources" },
  { id: "upwork", label: "Upwork" },
  { id: "linkedin", label: "LinkedIn" },
  { id: "indeed", label: "Indeed" },
  { id: "freelancer", label: "Freelancer" },
];

const statusColors: Record<string, string> = {
  new: "bg-[#00D4FF]/20 text-[#00D4FF]",
  saved: "bg-[#7B61FF]/20 text-[#7B61FF]",
  applied: "bg-[#FFB800]/20 text-[#FFB800]",
  viewed: "bg-[#7A8BA9]/20 text-[#7A8BA9]",
  interview: "bg-emerald-400/20 text-emerald-400",
  rejected: "bg-red-400/20 text-red-400",
  hired: "bg-[#00E396]/20 text-[#00E396]",
};

const sampleJobs = [
  {
    id: 1,
    title: "Full Stack Developer — SaaS Platform",
    company: "TechVenture Inc.",
    source: "upwork",
    budget: "$50-80/hr",
    budgetType: "hourly",
    skills: ["React", "Node.js", "PostgreSQL", "AWS"],
    description: "We're looking for an experienced full-stack developer to join our team building a next-generation SaaS platform. You'll work on React frontend, Node.js backend, and AWS infrastructure.",
    status: "new",
    createdAt: new Date(Date.now() - 3600000),
  },
  {
    id: 2,
    title: "React + TypeScript Frontend Engineer",
    company: "DesignStudio",
    source: "linkedin",
    budget: "$6,000",
    budgetType: "fixed",
    skills: ["React", "TypeScript", "Tailwind CSS", "Figma"],
    description: "Join our design-focused engineering team. You'll build beautiful, performant user interfaces using React, TypeScript, and Tailwind CSS.",
    status: "saved",
    createdAt: new Date(Date.now() - 7200000),
  },
  {
    id: 3,
    title: "AI Integration Specialist",
    company: "DataDriven AI",
    source: "indeed",
    budget: "$45-65/hr",
    budgetType: "hourly",
    skills: ["Python", "OpenAI API", "LangChain", "React"],
    description: "Help us integrate cutting-edge AI capabilities into our products. Experience with OpenAI API, LangChain, and modern web frameworks required.",
    status: "applied",
    createdAt: new Date(Date.now() - 10800000),
  },
  {
    id: 4,
    title: "Senior Frontend Developer",
    company: "StartupXYZ",
    source: "upwork",
    budget: "$70-100/hr",
    budgetType: "hourly",
    skills: ["Next.js", "TypeScript", "GraphQL", "Prisma"],
    description: "Lead frontend development for our fast-growing startup. We're building the future of work collaboration tools.",
    status: "interview",
    createdAt: new Date(Date.now() - 14400000),
  },
];

export default function Jobs() {
  const { addToast } = useAppStore();
  const [activeTab, setActiveTab] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedJob, setSelectedJob] = useState<any>(null);
  const [showProposal, setShowProposal] = useState(false);
  const [proposalText, setProposalText] = useState("");

  const utils = trpc.useUtils();
  const { data: jobs } = trpc.job.list.useQuery({
    status: "all",
    source: activeTab !== "all" ? activeTab : undefined,
  });

  const updateJob = trpc.job.update.useMutation({
    onSuccess: () => {
      utils.job.list.invalidate();
      utils.job.stats.invalidate();
      addToast("success", "Job updated");
    },
  });

  const handleApply = () => {
    if (selectedJob) {
      updateJob.mutate({
        id: selectedJob.id,
        status: "applied",
        proposal: proposalText,
        appliedAt: new Date().toISOString(),
      });
      setShowProposal(false);
      setSelectedJob(null);
    }
  };

  const handleGenerateProposal = () => {
    setProposalText(`Dear Hiring Manager,\n\nI came across your posting for ${selectedJob?.title} and I'm excited about the opportunity. With extensive experience in ${selectedJob?.skills?.join(", ") || "relevant technologies"}, I'm confident I can deliver exceptional results.\n\nI've successfully completed similar projects, delivering high-quality code on time and within budget. My approach combines technical expertise with clear communication to ensure project success.\n\nI'd welcome the chance to discuss how my skills align with your needs. I'm available for an interview at your convenience.\n\nBest regards`);
  };

  const allJobs = [...(jobs || []), ...sampleJobs.filter(sj => !(jobs || []).some(j => j.title === sj.title))];

  const filteredJobs = allJobs.filter((job) => {
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return job.title.toLowerCase().includes(q) || (job.company || "").toLowerCase().includes(q);
    }
    return true;
  });

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2 bg-[#0D1320] rounded-lg p-1 border border-white/[0.06] overflow-x-auto">
          {sourceTabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                "px-3 py-1.5 rounded-md text-sm whitespace-nowrap transition-colors",
                activeTab === tab.id ? "bg-[#00D4FF]/20 text-[#00D4FF]" : "text-[#7A8BA9] hover:text-white"
              )}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#4A5570]" />
        <input
          type="text"
          placeholder="Search jobs by title, company, or skills..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full h-10 pl-10 pr-4 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white placeholder-[#4A5570] focus:outline-none focus:border-[#00D4FF]/40 transition-all"
        />
      </div>

      {/* Jobs Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredJobs.map((job) => (
          <div
            key={job.id}
            className="glass rounded-xl p-5 card-hover cursor-pointer"
            onClick={() => {
              setSelectedJob(job);
              setShowProposal(false);
              setProposalText("");
            }}
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className={cn("text-xs px-2 py-0.5 rounded-full uppercase", statusColors[job.status as string] || statusColors.new)}>
                  {job.status}
                </span>
                <span className="text-xs text-[#4A5570] capitalize">{job.source}</span>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  updateJob.mutate({ id: job.id, status: job.status === "saved" ? "new" : "saved" });
                }}
                className="text-[#4A5570] hover:text-[#FFB800] transition-colors"
              >
                <Bookmark className={cn("w-4 h-4", job.status === "saved" && "fill-[#FFB800] text-[#FFB800]")} />
              </button>
            </div>
            <h4 className="text-base font-semibold text-white mb-1">{job.title}</h4>
            <p className="text-sm text-[#7A8BA9] mb-3">{job.company || "Unknown Company"}</p>
            <div className="flex items-center gap-4 text-xs text-[#7A8BA9] mb-3">
              <span className="flex items-center gap-1">
                <DollarSign className="w-3.5 h-3.5" />
                {job.budget || "Not specified"}
              </span>
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                {job.createdAt ? format(new Date(job.createdAt), "MMM d") : "Recently"}
              </span>
            </div>
            {job.skills && Array.isArray(job.skills) && (job.skills as string[]).length > 0 && (
              <div className="flex flex-wrap gap-1.5">
                {(job.skills as string[]).map((skill: string) => (
                  <span key={skill} className="text-[10px] bg-[#0D1320] text-[#00D4FF] px-2 py-0.5 rounded-full border border-[#00D4FF]/20">
                    {skill}
                  </span>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>

      {filteredJobs.length === 0 && (
        <div className="flex flex-col items-center justify-center py-16 text-[#4A5570]">
          <Briefcase className="w-12 h-12 mb-3 opacity-50" />
          <p className="text-sm">No jobs found matching your criteria</p>
        </div>
      )}

      {/* Job Detail Modal */}
      {selectedJob && !showProposal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="glass-strong rounded-2xl p-6 w-full max-w-lg max-h-[80vh] overflow-y-auto animate-slide-in">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold text-white">{selectedJob.title}</h3>
                <p className="text-sm text-[#7A8BA9]">{selectedJob.company}</p>
              </div>
              <button onClick={() => setSelectedJob(null)} className="text-[#4A5570] hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex items-center gap-4 text-sm text-[#7A8BA9] mb-4">
              <span className="flex items-center gap-1">
                <DollarSign className="w-4 h-4" />
                {selectedJob.budget}
              </span>
              <span className="flex items-center gap-1 capitalize">
                <Briefcase className="w-4 h-4" />
                {selectedJob.source}
              </span>
              <span className={cn("text-xs px-2 py-0.5 rounded-full", statusColors[selectedJob.status as string])}>
                {selectedJob.status}
              </span>
            </div>
            <p className="text-sm text-[#E8ECF4] mb-4">{selectedJob.description}</p>
            {selectedJob.skills && Array.isArray(selectedJob.skills) && (selectedJob.skills as string[]).length > 0 && (
              <div className="flex flex-wrap gap-1.5 mb-4">
                {(selectedJob.skills as string[]).map((skill: string) => (
                  <span key={skill} className="text-xs bg-[#0D1320] text-[#00D4FF] px-2 py-1 rounded-full border border-[#00D4FF]/20">
                    {skill}
                  </span>
                ))}
              </div>
            )}
            <div className="flex gap-3">
              <button
                onClick={() => setShowProposal(true)}
                className="flex-1 flex items-center justify-center gap-2 h-10 gradient-accent text-white text-sm font-medium rounded-lg hover:opacity-90 transition-opacity"
              >
                <Send className="w-4 h-4" />
                Apply Now
              </button>
              <button
                onClick={() => {
                  updateJob.mutate({ id: selectedJob.id, status: "saved" });
                  setSelectedJob(null);
                }}
                className="flex items-center justify-center gap-2 h-10 px-4 bg-[#0D1320] border border-white/[0.08] text-white text-sm rounded-lg hover:bg-white/[0.04] transition-colors"
              >
                <Bookmark className="w-4 h-4" />
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Proposal Modal */}
      {showProposal && selectedJob && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="glass-strong rounded-2xl p-6 w-full max-w-lg max-h-[80vh] overflow-y-auto animate-slide-in">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-white">Submit Proposal</h3>
              <button onClick={() => setShowProposal(false)} className="text-[#4A5570] hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="mb-4">
              <p className="text-sm text-[#7A8BA9]">Applying to: <span className="text-white">{selectedJob.title}</span></p>
            </div>
            <textarea
              value={proposalText}
              onChange={(e) => setProposalText(e.target.value)}
              rows={12}
              className="w-full px-4 py-3 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white placeholder-[#4A5570] focus:outline-none focus:border-[#00D4FF]/40 resize-none mb-4"
              placeholder="Write your proposal cover letter..."
            />
            <div className="flex gap-3">
              <button
                onClick={handleGenerateProposal}
                className="flex items-center justify-center gap-2 h-10 px-4 bg-[#0D1320] border border-[#7B61FF]/30 text-[#7B61FF] text-sm rounded-lg hover:bg-[#7B61FF]/10 transition-colors"
              >
                <Sparkles className="w-4 h-4" />
                AI Generate
              </button>
              <button
                onClick={handleApply}
                disabled={!proposalText.trim()}
                className="flex-1 flex items-center justify-center gap-2 h-10 gradient-accent text-white text-sm font-medium rounded-lg hover:opacity-90 transition-opacity disabled:opacity-50"
              >
                <Send className="w-4 h-4" />
                Submit Application
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
