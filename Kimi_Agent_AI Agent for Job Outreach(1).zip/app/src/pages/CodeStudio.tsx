import { useState, useEffect, useRef } from "react";
import { useAppStore } from "@/store/appStore";
import {
  Copy,
  Download,
  Send,
  FileCode,
  FolderOpen,
  Sparkles,
  Terminal,
  ChevronRight,
  X,
  RefreshCw,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface CodeFile {
  name: string;
  content: string;
  language: string;
}

interface Project {
  id: string;
  name: string;
  language: string;
  files: CodeFile[];
}

const sampleProjects: Project[] = [
  {
    id: "1",
    name: "React Contact Form",
    language: "tsx",
    files: [
      {
        name: "ContactForm.tsx",
        language: "tsx",
        content: `import { useState } from 'react';
import { z } from 'zod';

const schema = z.object({
  name: z.string().min(2, "Name is required"),
  email: z.string().email("Invalid email"),
  message: z.string().min(10, "Message too short"),
});

export function ContactForm() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = schema.safeParse(form);
    if (result.success) {
      setSubmitted(true);
      setErrors({});
    } else {
      const errs: Record<string, string> = {};
      result.error.errors.forEach((err) => {
        errs[err.path[0]] = err.message;
      });
      setErrors(errs);
    }
  };

  if (submitted) {
    return (
      <div className="p-6 bg-emerald-50 rounded-lg text-center">
        <h3 className="text-emerald-700 font-semibold">Thank you!</h3>
        <p className="text-emerald-600">We'll get back to you soon.</p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4 max-w-md">
      <div>
        <label className="block text-sm font-medium mb-1">Name</label>
        <input
          type="text"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          className="w-full px-3 py-2 border rounded-lg"
        />
        {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
      </div>
      <div>
        <label className="block text-sm font-medium mb-1">Email</label>
        <input
          type="email"
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
          className="w-full px-3 py-2 border rounded-lg"
        />
        {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
      </div>
      <div>
        <label className="block text-sm font-medium mb-1">Message</label>
        <textarea
          rows={4}
          value={form.message}
          onChange={(e) => setForm({ ...form, message: e.target.value })}
          className="w-full px-3 py-2 border rounded-lg"
        />
        {errors.message && <p className="text-red-500 text-xs mt-1">{errors.message}</p>}
      </div>
      <button type="submit" className="w-full py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
        Send Message
      </button>
    </form>
  );
}`,
      },
    ],
  },
  {
    id: "2",
    name: "Job Scraper",
    language: "python",
    files: [
      {
        name: "scraper.py",
        language: "python",
        content: `import requests
from bs4 import BeautifulSoup
import json
from datetime import datetime

class JobScraper:
    def __init__(self):
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        self.jobs = []
    
    def scrape_upwork(self, query="python developer"):
        url = f"https://www.upwork.com/nx/jobs/search/?q={query}"
        response = requests.get(url, headers=self.headers)
        soup = BeautifulSoup(response.content, 'html.parser')
        
        job_cards = soup.find_all('article', class_='job-tile')
        
        for card in job_cards[:10]:
            job = {
                'title': card.find('h2').text.strip() if card.find('h2') else 'N/A',
                'budget': card.find('span', class_='budget').text.strip() if card.find('span', class_='budget') else 'Not specified',
                'posted': card.find('span', class_='posted').text.strip() if card.find('span', class_='posted') else 'Unknown',
                'link': 'https://www.upwork.com' + card.find('a')['href'] if card.find('a') else ''
            }
            self.jobs.append(job)
        
        return self.jobs
    
    def save_to_json(self, filename=None):
        if not filename:
            filename = f"jobs_{datetime.now().strftime('%Y%m%d')}.json"
        
        with open(filename, 'w') as f:
            json.dump(self.jobs, f, indent=2)
        
        print(f"Saved {len(self.jobs)} jobs to {filename}")

if __name__ == "__main__":
    scraper = JobScraper()
    jobs = scraper.scrape_upwork("react developer")
    scraper.save_to_json()
    
    for job in jobs[:5]:
        print(f"Title: {job['title']}")
        print(f"Budget: {job['budget']}")
        print(f"Link: {job['link']}")
        print()`,
      },
    ],
  },
];

const chatMessages = [
  { id: 1, role: "user" as const, content: "Generate a React contact form with Zod validation" },
  { id: 2, role: "assistant" as const, content: "I've created a complete React contact form with Zod validation. The form includes name, email, and message fields with proper error handling and success state. You can see the generated code in the editor." },
];

const languageColors: Record<string, string> = {
  tsx: "#00D4FF",
  ts: "#00D4FF",
  jsx: "#00D4FF",
  js: "#FFB800",
  python: "#7B61FF",
  py: "#7B61FF",
  css: "#00E396",
  html: "#FF4560",
};

export default function CodeStudio() {
  const { addToast } = useAppStore();
  const [projects, setProjects] = useState<Project[]>(sampleProjects);
  const [activeProject, setActiveProject] = useState<Project>(sampleProjects[0]);
  const [activeFile, setActiveFile] = useState<CodeFile>(sampleProjects[0].files[0]);
  const [showChat, setShowChat] = useState(true);
  const [chatInput, setChatInput] = useState("");
  const [messages, setMessages] = useState(chatMessages);
  const [prompt, setPrompt] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleGenerate = () => {
    if (!prompt.trim()) return;
    setIsGenerating(true);
    
    setTimeout(() => {
      const newFile: CodeFile = {
        name: "GeneratedComponent.tsx",
        language: "tsx",
        content: `// Generated by NexusAI
// Prompt: ${prompt}

import { useState } from 'react';

export function GeneratedComponent() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleAction = async () => {
    setLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    setData([...data, { id: Date.now(), value: 'New Item' }]);
    setLoading(false);
  };

  return (
    <div className="p-6 space-y-4">
      <h2 className="text-2xl font-bold">Generated Component</h2>
      <button
        onClick={handleAction}
        disabled={loading}
        className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
      >
        {loading ? 'Loading...' : 'Add Item'}
      </button>
      <ul className="space-y-2">
        {data.map(item => (
          <li key={item.id} className="p-3 bg-gray-100 rounded-lg">
            {item.value}
          </li>
        ))}
      </ul>
    </div>
  );
}`,
      };

      const updatedProject = {
        ...activeProject,
        files: [...activeProject.files, newFile],
      };

      setActiveProject(updatedProject);
      setActiveFile(newFile);
      setProjects(projects.map(p => p.id === updatedProject.id ? updatedProject : p));
      setIsGenerating(false);
      addToast("success", "Code generated successfully!");
    }, 1500);
  };

  const handleSendMessage = () => {
    if (!chatInput.trim()) return;
    const newMessage = { id: messages.length + 1, role: "user" as const, content: chatInput };
    setMessages([...messages, newMessage]);
    setChatInput("");

    setTimeout(() => {
      const response = {
        id: messages.length + 2,
        role: "assistant" as const,
        content: "I understand. I'll help you with that. Let me generate the code based on your requirements.",
      };
      setMessages(prev => [...prev, response]);
    }, 500);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(activeFile.content);
    addToast("success", "Code copied to clipboard!");
  };

  const handleDownload = () => {
    const blob = new Blob([activeFile.content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = activeFile.name;
    a.click();
    URL.revokeObjectURL(url);
    addToast("success", "File downloaded!");
  };

  return (
    <div className="h-[calc(100vh-64px)] flex">
      {/* Left Panel: File Explorer */}
      <div className="w-[240px] bg-[#0a0f1c] border-r border-white/[0.06] flex flex-col">
        <div className="p-4 border-b border-white/[0.06]">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-semibold text-[#7A8BA9] uppercase tracking-wider">Projects</h3>
            <button className="text-[#4A5570] hover:text-[#00D4FF] transition-colors">
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-2 space-y-1 scrollbar-thin">
          {projects.map((project) => (
            <div key={project.id}>
              <button
                onClick={() => {
                  setActiveProject(project);
                  setActiveFile(project.files[0]);
                }}
                className={cn(
                  "w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-colors",
                  activeProject.id === project.id
                    ? "bg-[#00D4FF]/10 text-[#00D4FF]"
                    : "text-[#7A8BA9] hover:text-white hover:bg-white/[0.04]"
                )}
              >
                <FolderOpen className="w-4 h-4" />
                <span className="truncate">{project.name}</span>
              </button>
              {activeProject.id === project.id && (
                <div className="ml-4 space-y-0.5">
                  {project.files.map((file) => (
                    <button
                      key={file.name}
                      onClick={() => setActiveFile(file)}
                      className={cn(
                        "w-full flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs transition-colors",
                        activeFile.name === file.name
                          ? "bg-[#00D4FF]/10 text-[#00D4FF]"
                          : "text-[#4A5570] hover:text-[#7A8BA9]"
                      )}
                    >
                      <FileCode className="w-3.5 h-3.5" style={{ color: languageColors[file.language] }} />
                      <span className="truncate">{file.name}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Center Panel: Code Editor */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Tabs */}
        <div className="flex items-center bg-[#0a0f1c] border-b border-white/[0.06] overflow-x-auto">
          {activeProject.files.map((file) => (
            <button
              key={file.name}
              onClick={() => setActiveFile(file)}
              className={cn(
                "flex items-center gap-2 px-4 py-2.5 text-sm border-r border-white/[0.06] whitespace-nowrap transition-colors",
                activeFile.name === file.name
                  ? "bg-[#070B14] text-white border-b-2 border-b-[#00D4FF]"
                  : "text-[#4A5570] hover:text-[#7A8BA9]"
              )}
            >
              <FileCode className="w-3.5 h-3.5" style={{ color: languageColors[file.language] }} />
              <span>{file.name}</span>
            </button>
          ))}
        </div>

        {/* Toolbar */}
        <div className="flex items-center justify-between px-4 py-2 bg-[#070B14] border-b border-white/[0.06]">
          <div className="flex items-center gap-1">
            <span className="text-xs text-[#4A5570]">{activeProject.name}</span>
            <ChevronRight className="w-3 h-3 text-[#4A5570]" />
            <span className="text-xs text-[#00D4FF]">{activeFile.name}</span>
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={handleCopyCode}
              className="p-1.5 text-[#4A5570] hover:text-white hover:bg-white/[0.04] rounded transition-colors"
              title="Copy"
            >
              <Copy className="w-4 h-4" />
            </button>
            <button
              onClick={handleDownload}
              className="p-1.5 text-[#4A5570] hover:text-white hover:bg-white/[0.04] rounded transition-colors"
              title="Download"
            >
              <Download className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Code Display */}
        <div className="flex-1 overflow-auto bg-[#070B14] scrollbar-thin">
          <pre className="p-4 text-sm leading-relaxed">
            <code className="text-[#E8ECF4] font-mono">
              {activeFile.content.split("\n").map((line, i) => (
                <div key={i} className="flex">
                  <span className="w-12 text-right text-[#4A5570] select-none mr-4 flex-shrink-0">
                    {i + 1}
                  </span>
                  <span className="text-[#E8ECF4]">{line || " "}</span>
                </div>
              ))}
            </code>
          </pre>
        </div>

        {/* AI Prompt Bar */}
        <div className="p-3 bg-[#0a0f1c] border-t border-white/[0.06]">
          <div className="flex items-center gap-2">
            <input
              type="text"
              placeholder="Describe what you want to build... (e.g., 'Create a login form with validation')"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleGenerate()}
              className="flex-1 h-10 px-4 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white placeholder-[#4A5570] focus:outline-none focus:border-[#00D4FF]/40"
            />
            <button
              onClick={handleGenerate}
              disabled={isGenerating || !prompt.trim()}
              className="flex items-center gap-2 h-10 px-5 gradient-accent text-white text-sm font-medium rounded-lg hover:opacity-90 transition-opacity disabled:opacity-50"
            >
              {isGenerating ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <Sparkles className="w-4 h-4" />
              )}
              <span>{isGenerating ? "Generating..." : "Generate"}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Right Panel: AI Chat */}
      {showChat && (
        <div className="w-[300px] bg-[#0a0f1c] border-l border-white/[0.06] flex flex-col">
          <div className="flex items-center justify-between p-3 border-b border-white/[0.06]">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-[#00D4FF]" />
              <span className="text-sm font-medium text-white">AI Assistant</span>
            </div>
            <button
              onClick={() => setShowChat(false)}
              className="text-[#4A5570] hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto p-3 space-y-3 scrollbar-thin">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={cn(
                  "p-3 rounded-lg text-xs leading-relaxed",
                  msg.role === "user"
                    ? "bg-[#00D4FF]/10 text-[#00D4FF] ml-4"
                    : "bg-[#0D1320] text-[#7A8BA9] mr-4"
                )}
              >
                {msg.content}
              </div>
            ))}
            <div ref={chatEndRef} />
          </div>
          <div className="p-3 border-t border-white/[0.06]">
            <div className="flex items-center gap-2">
              <input
                type="text"
                placeholder="Ask about the code..."
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
                className="flex-1 h-9 px-3 bg-[#0D1320] border border-white/[0.08] rounded-lg text-xs text-white placeholder-[#4A5570] focus:outline-none focus:border-[#00D4FF]/40"
              />
              <button
                onClick={handleSendMessage}
                className="p-2 text-[#00D4FF] hover:bg-[#00D4FF]/10 rounded-lg transition-colors"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
