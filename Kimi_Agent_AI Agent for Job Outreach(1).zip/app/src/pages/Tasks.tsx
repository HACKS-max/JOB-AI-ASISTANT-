import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { useAppStore } from "@/store/appStore";
import {
  CheckSquare,
  Plus,
  Search,
  Calendar,
  User,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { format } from "date-fns";

type TaskStatus = "backlog" | "in_progress" | "review" | "done" | "failed";
type TaskPriority = "low" | "medium" | "high" | "urgent";

const statusColors: Record<TaskStatus, string> = {
  backlog: "bg-[#7A8BA9]/20 text-[#7A8BA9]",
  in_progress: "bg-[#00D4FF]/20 text-[#00D4FF]",
  review: "bg-[#7B61FF]/20 text-[#7B61FF]",
  done: "bg-[#00E396]/20 text-[#00E396]",
  failed: "bg-[#FF4560]/20 text-[#FF4560]",
};

const priorityColors: Record<TaskPriority, string> = {
  low: "text-[#7A8BA9]",
  medium: "text-[#FFB800]",
  high: "text-[#FF4560]",
  urgent: "text-[#FF4560] animate-pulse",
};

const columns: { id: TaskStatus; label: string }[] = [
  { id: "backlog", label: "Backlog" },
  { id: "in_progress", label: "In Progress" },
  { id: "review", label: "Review" },
  { id: "done", label: "Done" },
];

export default function Tasks() {
  const { openModal, addToast } = useAppStore();
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [filterPriority, setFilterPriority] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState<"board" | "list">("board");

  const utils = trpc.useUtils();
  const { data: tasks } = trpc.task.list.useQuery({
    status: filterStatus !== "all" ? filterStatus : undefined,
    priority: filterPriority !== "all" ? filterPriority : undefined,
    search: searchQuery || undefined,
  });

  const deleteTask = trpc.task.delete.useMutation({
    onSuccess: () => {
      utils.task.list.invalidate();
      utils.task.stats.invalidate();
      addToast("success", "Task deleted");
    },
  });

  const handleDelete = (taskId: number) => {
    if (confirm("Are you sure you want to delete this task?")) {
      deleteTask.mutate({ id: taskId });
    }
  };

  const filteredTasks = tasks?.filter((task) => {
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        task.title.toLowerCase().includes(q) ||
        (task.description || "").toLowerCase().includes(q)
      );
    }
    return true;
  });

  const tasksByStatus = (status: TaskStatus) =>
    filteredTasks?.filter((t) => t.status === status) || [];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="flex items-center bg-[#0D1320] rounded-lg p-1 border border-white/[0.06]">
            <button
              onClick={() => setViewMode("board")}
              className={cn(
                "px-3 py-1.5 rounded-md text-sm transition-colors",
                viewMode === "board" ? "bg-[#00D4FF]/20 text-[#00D4FF]" : "text-[#7A8BA9] hover:text-white"
              )}
            >
              Board
            </button>
            <button
              onClick={() => setViewMode("list")}
              className={cn(
                "px-3 py-1.5 rounded-md text-sm transition-colors",
                viewMode === "list" ? "bg-[#00D4FF]/20 text-[#00D4FF]" : "text-[#7A8BA9] hover:text-white"
              )}
            >
              List
            </button>
          </div>
        </div>
        <button
          onClick={() => openModal("create-task")}
          className="flex items-center gap-2 h-10 px-5 gradient-accent text-white text-sm font-medium rounded-full hover:opacity-90 transition-opacity"
        >
          <Plus className="w-4 h-4" />
          New Task
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
        <div className="relative flex-1 max-w-sm w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#4A5570]" />
          <input
            type="text"
            placeholder="Search tasks..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-10 pl-10 pr-4 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white placeholder-[#4A5570] focus:outline-none focus:border-[#00D4FF]/40 transition-all"
          />
        </div>
        <div className="flex items-center gap-2">
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="h-10 px-3 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white focus:outline-none focus:border-[#00D4FF]/40"
          >
            <option value="all">All Status</option>
            <option value="backlog">Backlog</option>
            <option value="in_progress">In Progress</option>
            <option value="review">Review</option>
            <option value="done">Done</option>
          </select>
          <select
            value={filterPriority}
            onChange={(e) => setFilterPriority(e.target.value)}
            className="h-10 px-3 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white focus:outline-none focus:border-[#00D4FF]/40"
          >
            <option value="all">All Priority</option>
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
            <option value="urgent">Urgent</option>
          </select>
        </div>
      </div>

      {/* Board View */}
      {viewMode === "board" ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {columns.map((column) => (
            <div key={column.id} className="space-y-3">
              <div className="flex items-center justify-between px-1">
                <h3 className="text-sm font-semibold text-white">{column.label}</h3>
                <span className="text-xs text-[#4A5570] bg-[#0D1320] px-2 py-0.5 rounded-full">
                  {tasksByStatus(column.id).length}
                </span>
              </div>
              <div className="space-y-2 min-h-[200px]">
                {tasksByStatus(column.id).map((task) => (
                  <div
                    key={task.id}
                    className="glass rounded-xl p-4 card-hover group cursor-pointer"
                    onClick={() => openModal("edit-task", task)}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <span className={cn("text-xs font-medium uppercase tracking-wider", priorityColors[task.priority as TaskPriority])}>
                        {task.priority}
                      </span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDelete(task.id);
                        }}
                        className="opacity-0 group-hover:opacity-100 text-[#4A5570] hover:text-red-400 transition-all"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <h4 className="text-sm font-medium text-white mb-2 line-clamp-2">{task.title}</h4>
                    {task.assignee && (
                      <div className="flex items-center gap-1.5 text-xs text-[#7A8BA9]">
                        <User className="w-3 h-3" />
                        <span>{task.assignee}</span>
                      </div>
                    )}
                    {task.dueDate && (
                      <div className="flex items-center gap-1.5 text-xs text-[#7A8BA9] mt-1">
                        <Calendar className="w-3 h-3" />
                        <span>{format(new Date(task.dueDate), "MMM d")}</span>
                      </div>
                    )}
                    {task.tags && Array.isArray(task.tags) && (task.tags as string[]).length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {(task.tags as string[]).map((tag: string) => (
                          <span key={tag} className="text-[10px] bg-[#0D1320] text-[#7A8BA9] px-1.5 py-0.5 rounded">
                            {tag}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
                <button
                  onClick={() => openModal("create-task", { status: column.id })}
                  className="w-full flex items-center justify-center gap-2 py-3 rounded-xl border border-dashed border-white/[0.08] text-[#4A5570] hover:text-[#00D4FF] hover:border-[#00D4FF]/30 transition-all"
                >
                  <Plus className="w-4 h-4" />
                  <span className="text-sm">Add Task</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* List View */
        <div className="glass rounded-2xl overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/[0.06]">
                <th className="text-left text-xs font-medium text-[#7A8BA9] uppercase tracking-wider px-4 py-3">Task</th>
                <th className="text-left text-xs font-medium text-[#7A8BA9] uppercase tracking-wider px-4 py-3">Status</th>
                <th className="text-left text-xs font-medium text-[#7A8BA9] uppercase tracking-wider px-4 py-3">Priority</th>
                <th className="text-left text-xs font-medium text-[#7A8BA9] uppercase tracking-wider px-4 py-3">Assignee</th>
                <th className="text-left text-xs font-medium text-[#7A8BA9] uppercase tracking-wider px-4 py-3">Due Date</th>
                <th className="text-right text-xs font-medium text-[#7A8BA9] uppercase tracking-wider px-4 py-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredTasks?.map((task) => (
                <tr
                  key={task.id}
                  className="border-b border-white/[0.04] hover:bg-white/[0.02] transition-colors cursor-pointer"
                  onClick={() => openModal("edit-task", task)}
                >
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <CheckSquare className="w-4 h-4 text-[#4A5570]" />
                      <span className="text-sm text-white">{task.title}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={cn("text-xs px-2 py-1 rounded-full", statusColors[task.status as TaskStatus])}>
                      {task.status.replace("_", " ")}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={cn("text-xs font-medium", priorityColors[task.priority as TaskPriority])}>
                      {task.priority}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm text-[#7A8BA9]">{task.assignee || "—"}</td>
                  <td className="px-4 py-3 text-sm text-[#7A8BA9]">
                    {task.dueDate ? format(new Date(task.dueDate), "MMM d, yyyy") : "—"}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDelete(task.id);
                      }}
                      className="text-[#4A5570] hover:text-red-400 transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
