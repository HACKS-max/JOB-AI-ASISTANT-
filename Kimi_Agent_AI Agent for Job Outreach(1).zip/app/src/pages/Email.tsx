import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { useAppStore } from "@/store/appStore";
import {
  Mail,
  Plus,
  Search,
  Send,
  Clock,
  CheckCircle2,
  XCircle,
  FileText,
  Trash2,
  Reply,
  Eye,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { format } from "date-fns";

const tabs = [
  { id: "all", label: "All", icon: Mail },
  { id: "sent", label: "Sent", icon: Send },
  { id: "scheduled", label: "Scheduled", icon: Clock },
  { id: "draft", label: "Drafts", icon: FileText },
  { id: "failed", label: "Failed", icon: XCircle },
];

export default function Email() {
  const { addToast } = useAppStore();
  const [activeTab, setActiveTab] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [showCompose, setShowCompose] = useState(false);
  const [selectedEmail, setSelectedEmail] = useState<any>(null);

  const [composeData, setComposeData] = useState({
    to: "",
    subject: "",
    body: "",
    scheduledAt: "",
  });

  const utils = trpc.useUtils();
  const { data: emails } = trpc.email.list.useQuery({
    status: activeTab !== "all" ? activeTab : undefined,
  });

  const createEmail = trpc.email.create.useMutation({
    onSuccess: () => {
      utils.email.list.invalidate();
      utils.email.stats.invalidate();
      setShowCompose(false);
      setComposeData({ to: "", subject: "", body: "", scheduledAt: "" });
      addToast("success", composeData.scheduledAt ? "Email scheduled" : "Email sent successfully");
    },
  });

  const deleteEmail = trpc.email.delete.useMutation({
    onSuccess: () => {
      utils.email.list.invalidate();
      setSelectedEmail(null);
      addToast("success", "Email deleted");
    },
  });

  const handleSend = () => {
    if (!composeData.to || !composeData.subject || !composeData.body) {
      addToast("error", "Please fill in all required fields");
      return;
    }
    createEmail.mutate({
      toEmails: composeData.to.split(",").map((e) => e.trim()),
      subject: composeData.subject,
      body: composeData.body,
      scheduledAt: composeData.scheduledAt || undefined,
      userId: 1,
    });
  };

  const filteredEmails = emails?.filter((email) => {
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        (email.subject || "").toLowerCase().includes(q) ||
        (email.body || "").toLowerCase().includes(q)
      );
    }
    return true;
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "sent": return <CheckCircle2 className="w-4 h-4 text-emerald-400" />;
      case "scheduled": return <Clock className="w-4 h-4 text-[#FFB800]" />;
      case "failed": return <XCircle className="w-4 h-4 text-red-400" />;
      default: return <FileText className="w-4 h-4 text-[#7A8BA9]" />;
    }
  };

  return (
    <div className="h-[calc(100vh-64px)] flex">
      {/* Left Panel: Email List */}
      <div className={cn("flex flex-col border-r border-white/[0.06] bg-[#070B14]/50", selectedEmail ? "w-[400px]" : "flex-1")}>
        {/* Header */}
        <div className="p-4 border-b border-white/[0.06]">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-white">Emails</h2>
            <button
              onClick={() => {
                setShowCompose(true);
                setSelectedEmail(null);
              }}
              className="flex items-center gap-2 h-9 px-4 gradient-accent text-white text-sm font-medium rounded-full hover:opacity-90 transition-opacity"
            >
              <Plus className="w-4 h-4" />
              Compose
            </button>
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#4A5570]" />
            <input
              type="text"
              placeholder="Search emails..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-10 pl-10 pr-4 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white placeholder-[#4A5570] focus:outline-none focus:border-[#00D4FF]/40 transition-all"
            />
          </div>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-1 px-4 py-2 border-b border-white/[0.06] overflow-x-auto">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                "flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors",
                activeTab === tab.id
                  ? "bg-[#00D4FF]/10 text-[#00D4FF]"
                  : "text-[#7A8BA9] hover:text-white hover:bg-white/[0.04]"
              )}
            >
              <tab.icon className="w-3.5 h-3.5" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Email List */}
        <div className="flex-1 overflow-y-auto scrollbar-thin">
          {showCompose && !selectedEmail ? (
            <div className="p-4 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold text-white">New Message</h3>
                <button onClick={() => setShowCompose(false)} className="text-[#4A5570] hover:text-white">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <input
                type="text"
                placeholder="To (comma-separated emails)"
                value={composeData.to}
                onChange={(e) => setComposeData({ ...composeData, to: e.target.value })}
                className="w-full h-10 px-4 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white placeholder-[#4A5570] focus:outline-none focus:border-[#00D4FF]/40"
              />
              <input
                type="text"
                placeholder="Subject"
                value={composeData.subject}
                onChange={(e) => setComposeData({ ...composeData, subject: e.target.value })}
                className="w-full h-10 px-4 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white placeholder-[#4A5570] focus:outline-none focus:border-[#00D4FF]/40"
              />
              <textarea
                placeholder="Write your message..."
                value={composeData.body}
                onChange={(e) => setComposeData({ ...composeData, body: e.target.value })}
                rows={12}
                className="w-full px-4 py-3 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white placeholder-[#4A5570] focus:outline-none focus:border-[#00D4FF]/40 resize-none"
              />
              <div className="flex items-center gap-2">
                <input
                  type="datetime-local"
                  value={composeData.scheduledAt}
                  onChange={(e) => setComposeData({ ...composeData, scheduledAt: e.target.value })}
                  className="h-10 px-3 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white focus:outline-none focus:border-[#00D4FF]/40"
                />
                <button
                  onClick={handleSend}
                  disabled={createEmail.isPending}
                  className="flex-1 flex items-center justify-center gap-2 h-10 gradient-accent text-white text-sm font-medium rounded-lg hover:opacity-90 transition-opacity disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                  {composeData.scheduledAt ? "Schedule" : "Send"}
                </button>
              </div>
            </div>
          ) : (
            <div className="divide-y divide-white/[0.04]">
              {filteredEmails?.map((email) => (
                <div
                  key={email.id}
                  onClick={() => setSelectedEmail(email)}
                  className={cn(
                    "p-4 cursor-pointer hover:bg-white/[0.02] transition-colors",
                    selectedEmail?.id === email.id ? "bg-white/[0.04] border-l-2 border-[#00D4FF]" : "border-l-2 border-transparent"
                  )}
                >
                  <div className="flex items-start gap-3">
                    {getStatusIcon(email.status || "draft")}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h4 className="text-sm font-medium text-white truncate">{email.subject || "(No Subject)"}</h4>
                        <span className="text-xs text-[#4A5570] ml-2 whitespace-nowrap">
                          {email.createdAt ? format(new Date(email.createdAt), "MMM d") : ""}
                        </span>
                      </div>
                      <p className="text-xs text-[#7A8BA9] truncate mt-0.5">
                        To: {(email.toEmails as string[])?.join(", ") || "No recipients"}
                      </p>
                      <p className="text-xs text-[#4A5570] truncate mt-1">
                        {(email.body || "").slice(0, 80)}...
                      </p>
                    </div>
                  </div>
                </div>
              ))}
              {filteredEmails?.length === 0 && (
                <div className="flex flex-col items-center justify-center py-16 text-[#4A5570]">
                  <Mail className="w-12 h-12 mb-3 opacity-50" />
                  <p className="text-sm">No emails found</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Right Panel: Email Detail */}
      {selectedEmail && (
        <div className="flex-1 flex flex-col bg-[#070B14]/30">
          <div className="flex items-center justify-between p-4 border-b border-white/[0.06]">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setSelectedEmail(null)}
                className="lg:hidden text-[#7A8BA9] hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
              <h3 className="text-sm font-semibold text-white">{selectedEmail.subject || "(No Subject)"}</h3>
            </div>
            <div className="flex items-center gap-2">
              <button className="p-2 text-[#7A8BA9] hover:text-white hover:bg-white/[0.04] rounded-lg transition-colors">
                <Reply className="w-4 h-4" />
              </button>
              <button className="p-2 text-[#7A8BA9] hover:text-white hover:bg-white/[0.04] rounded-lg transition-colors">
                <Eye className="w-4 h-4" />
              </button>
              <button
                onClick={() => deleteEmail.mutate({ id: selectedEmail.id })}
                className="p-2 text-[#7A8BA9] hover:text-red-400 hover:bg-red-400/10 rounded-lg transition-colors"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
          <div className="p-6 space-y-4 overflow-y-auto">
            <div className="flex items-center gap-3 text-sm">
              <span className="text-[#7A8BA9]">From:</span>
              <span className="text-white">{selectedEmail.fromEmail || "me"}</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <span className="text-[#7A8BA9]">To:</span>
              <span className="text-white">{(selectedEmail.toEmails as string[])?.join(", ")}</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <span className="text-[#7A8BA9]">Date:</span>
              <span className="text-white">
                {selectedEmail.createdAt ? format(new Date(selectedEmail.createdAt), "MMM d, yyyy 'at' h:mm a") : ""}
              </span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <span className="text-[#7A8BA9]">Status:</span>
              <span className={cn(
                "text-xs px-2 py-0.5 rounded-full",
                selectedEmail.status === "sent" && "bg-emerald-400/20 text-emerald-400",
                selectedEmail.status === "scheduled" && "bg-[#FFB800]/20 text-[#FFB800]",
                selectedEmail.status === "draft" && "bg-[#7A8BA9]/20 text-[#7A8BA9]",
                selectedEmail.status === "failed" && "bg-red-400/20 text-red-400",
              )}>
                {selectedEmail.status || "draft"}
              </span>
            </div>
            <div className="border-t border-white/[0.06] pt-4">
              <p className="text-sm text-white/90 whitespace-pre-wrap">{selectedEmail.body}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
