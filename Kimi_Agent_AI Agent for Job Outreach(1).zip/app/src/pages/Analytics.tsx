import { useState } from "react";
import { trpc } from "@/providers/trpc";
import {
  TrendingUp,
  TrendingDown,
  CheckSquare,
  Mail,
  Phone,
  Briefcase,
  Code2,
  Clock,
} from "lucide-react";
import { cn } from "@/lib/utils";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell,
  PieChart,
  Pie,
} from "recharts";

const dateRanges = [
  { id: "today", label: "Today" },
  { id: "7d", label: "7 Days" },
  { id: "30d", label: "30 Days" },
  { id: "90d", label: "90 Days" },
];

const activityData = [
  { day: "Mon", tasks: 12, emails: 45, calls: 3 },
  { day: "Tue", tasks: 18, emails: 62, calls: 5 },
  { day: "Wed", tasks: 8, emails: 38, calls: 2 },
  { day: "Thu", tasks: 22, emails: 78, calls: 7 },
  { day: "Fri", tasks: 15, emails: 55, calls: 4 },
  { day: "Sat", tasks: 6, emails: 20, calls: 1 },
  { day: "Sun", tasks: 4, emails: 15, calls: 0 },
];

const emailPerformance = [
  { type: "Sent", count: 328, color: "#00D4FF" },
  { type: "Opened", count: 142, color: "#7B61FF" },
  { type: "Clicked", count: 68, color: "#00E396" },
  { type: "Replied", count: 45, color: "#FFB800" },
  { type: "Bounced", count: 12, color: "#FF4560" },
];

const taskDistribution = [
  { name: "Completed", value: 142, color: "#00E396" },
  { name: "In Progress", value: 24, color: "#00D4FF" },
  { name: "Backlog", value: 38, color: "#7A8BA9" },
  { name: "Failed", value: 8, color: "#FF4560" },
];

const metrics = [
  {
    label: "Tasks Completed",
    value: "142",
    change: "+12%",
    up: true,
    icon: CheckSquare,
    color: "#00D4FF",
  },
  {
    label: "Emails Sent",
    value: "892",
    change: "+8%",
    up: true,
    icon: Mail,
    color: "#7B61FF",
  },
  {
    label: "Calls Made",
    value: "24",
    change: "+5%",
    up: true,
    icon: Phone,
    color: "#00E396",
  },
  {
    label: "Jobs Applied",
    value: "18",
    change: "+15%",
    up: true,
    icon: Briefcase,
    color: "#FFB800",
  },
  {
    label: "Code Files Generated",
    value: "47",
    change: "+22%",
    up: true,
    icon: Code2,
    color: "#FF4560",
  },
  {
    label: "Time Saved",
    value: "47h",
    change: "+18%",
    up: true,
    icon: Clock,
    color: "#00D4FF",
  },
];

export default function Analytics() {
  const [dateRange, setDateRange] = useState("7d");

  trpc.task.stats.useQuery();
  trpc.email.stats.useQuery();
  trpc.call.stats.useQuery();

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold text-white">Analytics Overview</h2>
          <p className="text-sm text-[#4A5570]">Track your AI agent&apos;s performance</p>
        </div>
        <div className="flex items-center gap-1 bg-[#0D1320] rounded-lg p-1 border border-white/[0.06]">
          {dateRanges.map((range) => (
            <button
              key={range.id}
              onClick={() => setDateRange(range.id)}
              className={cn(
                "px-3 py-1.5 rounded-md text-sm transition-colors",
                dateRange === range.id ? "bg-[#00D4FF]/20 text-[#00D4FF]" : "text-[#7A8BA9] hover:text-white"
              )}
            >
              {range.label}
            </button>
          ))}
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {metrics.map((metric) => (
          <div key={metric.label} className="glass rounded-2xl p-5 card-hover">
            <div className="flex items-start justify-between">
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{ backgroundColor: `${metric.color}15` }}
              >
                <metric.icon className="w-5 h-5" style={{ color: metric.color }} />
              </div>
              <div className="flex items-center gap-1 text-xs">
                {metric.up ? (
                  <TrendingUp className="w-3 h-3 text-emerald-400" />
                ) : (
                  <TrendingDown className="w-3 h-3 text-red-400" />
                )}
                <span className={metric.up ? "text-emerald-400" : "text-red-400"}>{metric.change}</span>
              </div>
            </div>
            <div className="mt-4">
              <p className="text-2xl font-bold text-white">{metric.value}</p>
              <p className="text-xs text-[#4A5570] mt-0.5">{metric.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Activity Timeline */}
        <div className="glass rounded-2xl p-6">
          <h3 className="text-sm font-semibold text-white mb-2 uppercase tracking-wider">Activity Timeline</h3>
          <p className="text-xs text-[#4A5570] mb-6">Tasks, emails, and calls over the past week</p>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={activityData}>
              <defs>
                <linearGradient id="colorTasks2" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00D4FF" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#00D4FF" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="colorEmails2" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#7B61FF" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#7B61FF" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="day" stroke="#4A5570" fontSize={11} />
              <YAxis stroke="#4A5570" fontSize={11} />
              <Tooltip
                contentStyle={{
                  background: "rgba(13,19,32,0.95)",
                  border: "1px solid rgba(255,255,255,0.1)",
                  borderRadius: "8px",
                }}
              />
              <Area type="monotone" dataKey="tasks" stroke="#00D4FF" fill="url(#colorTasks2)" strokeWidth={2} name="Tasks" />
              <Area type="monotone" dataKey="emails" stroke="#7B61FF" fill="url(#colorEmails2)" strokeWidth={2} name="Emails" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Email Performance */}
        <div className="glass rounded-2xl p-6">
          <h3 className="text-sm font-semibold text-white mb-2 uppercase tracking-wider">Email Performance</h3>
          <p className="text-xs text-[#4A5570] mb-6">Breakdown of email metrics</p>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={emailPerformance}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="type" stroke="#4A5570" fontSize={11} />
              <YAxis stroke="#4A5570" fontSize={11} />
              <Tooltip
                contentStyle={{
                  background: "rgba(13,19,32,0.95)",
                  border: "1px solid rgba(255,255,255,0.1)",
                  borderRadius: "8px",
                }}
              />
              <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                {emailPerformance.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Task Distribution */}
        <div className="glass rounded-2xl p-6">
          <h3 className="text-sm font-semibold text-white mb-2 uppercase tracking-wider">Task Distribution</h3>
          <p className="text-xs text-[#4A5570] mb-6">By status</p>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={taskDistribution}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={80}
                paddingAngle={3}
                dataKey="value"
              >
                {taskDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  background: "rgba(13,19,32,0.95)",
                  border: "1px solid rgba(255,255,255,0.1)",
                  borderRadius: "8px",
                }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex flex-wrap gap-3 justify-center mt-2">
            {taskDistribution.map((item) => (
              <div key={item.name} className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-xs text-[#7A8BA9]">{item.name}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Efficiency Score */}
        <div className="glass rounded-2xl p-6">
          <h3 className="text-sm font-semibold text-white mb-2 uppercase tracking-wider">Agent Efficiency</h3>
          <p className="text-xs text-[#4A5570] mb-6">Overall performance score</p>
          <div className="flex items-center justify-center py-4">
            <div className="relative w-36 h-36">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="42" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="8" />
                <circle
                  cx="50"
                  cy="50"
                  r="42"
                  fill="none"
                  stroke="url(#gradient)"
                  strokeWidth="8"
                  strokeLinecap="round"
                  strokeDasharray={`${0.87 * 264} 264`}
                />
                <defs>
                  <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#00D4FF" />
                    <stop offset="100%" stopColor="#7B61FF" />
                  </linearGradient>
                </defs>
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-3xl font-bold text-white">87%</span>
                <span className="text-xs text-[#7A8BA9]">Efficiency</span>
              </div>
            </div>
          </div>
          <div className="space-y-2 mt-4">
            <div className="flex items-center justify-between text-sm">
              <span className="text-[#7A8BA9]">Task Completion Rate</span>
              <span className="text-white font-medium">94%</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-[#7A8BA9]">Email Open Rate</span>
              <span className="text-white font-medium">34%</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-[#7A8BA9]">Call Success Rate</span>
              <span className="text-white font-medium">88%</span>
            </div>
          </div>
        </div>

        {/* Top Templates */}
        <div className="glass rounded-2xl p-6">
          <h3 className="text-sm font-semibold text-white mb-2 uppercase tracking-wider">Top Templates</h3>
          <p className="text-xs text-[#4A5570] mb-6">Most used email templates</p>
          <div className="space-y-3">
            {[
              { name: "Welcome Email", uses: 156, openRate: "42%" },
              { name: "Follow-up", uses: 98, openRate: "38%" },
              { name: "Meeting Request", uses: 67, openRate: "45%" },
              { name: "Proposal Send", uses: 45, openRate: "52%" },
              { name: "Thank You", uses: 34, openRate: "41%" },
            ].map((template) => (
              <div key={template.name} className="flex items-center justify-between py-2 border-b border-white/[0.04]">
                <div>
                  <p className="text-sm text-white">{template.name}</p>
                  <p className="text-xs text-[#4A5570]">{template.uses} uses</p>
                </div>
                <span className="text-sm text-emerald-400">{template.openRate}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
