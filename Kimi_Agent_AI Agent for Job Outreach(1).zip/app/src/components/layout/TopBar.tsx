import { useLocation } from "react-router";
import { useAppStore } from "@/store/appStore";
import { useAuth } from "@/hooks/useAuth";
import {
  Search,
  Bell,
  Plus,
  Command,
} from "lucide-react";

const pageTitles: Record<string, string> = {
  "/": "Dashboard",
  "/tasks": "Task Manager",
  "/email": "Email Center",
  "/calls": "Call Hub",
  "/code": "Code Studio",
  "/jobs": "Job Center",
  "/people": "People Directory",
  "/analytics": "Analytics",
  "/settings": "Settings",
};

export function TopBar() {
  const location = useLocation();
  const { openModal } = useAppStore();
  const { user } = useAuth();

  const title = pageTitles[location.pathname] || "Dashboard";

  return (
    <header className="h-16 bg-[#070B14]/80 backdrop-blur-xl border-b border-white/[0.06] flex items-center justify-between px-6 sticky top-0 z-40">
      {/* Left: Title */}
      <div>
        <h1 className="text-lg font-semibold text-white">{title}</h1>
        <p className="text-xs text-[#4A5570]">
          {new Date().toLocaleDateString("en-US", {
            weekday: "long",
            year: "numeric",
            month: "long",
            day: "numeric",
          })}
        </p>
      </div>

      {/* Center: Search */}
      <div className="hidden md:flex items-center max-w-md w-full mx-8">
        <div className="relative w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#4A5570]" />
          <input
            type="text"
            placeholder="Search tasks, emails, contacts..."
            className="w-full h-9 pl-10 pr-10 bg-[#0D1320] border border-white/[0.08] rounded-lg text-sm text-white placeholder-[#4A5570] focus:outline-none focus:border-[#00D4FF]/40 focus:ring-1 focus:ring-[#00D4FF]/20 transition-all"
          />
          <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1 text-[#4A5570]">
            <Command className="w-3 h-3" />
            <span className="text-xs">K</span>
          </div>
        </div>
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => openModal("quickTask")}
          className="hidden sm:flex items-center gap-2 h-9 px-4 gradient-accent text-white text-sm font-medium rounded-full hover:opacity-90 transition-opacity"
        >
          <Plus className="w-4 h-4" />
          <span>New Task</span>
        </button>

        <button className="relative w-9 h-9 flex items-center justify-center rounded-lg bg-[#0D1320] border border-white/[0.08] text-[#7A8BA9] hover:text-white transition-colors">
          <Bell className="w-4 h-4" />
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#FF4560] rounded-full text-[9px] text-white flex items-center justify-center font-semibold">
            3
          </span>
        </button>

        {user?.avatar && (
          <img
            src={user.avatar}
            alt={user.name || "User"}
            className="w-8 h-8 rounded-full border border-white/[0.1]"
          />
        )}
      </div>
    </header>
  );
}
