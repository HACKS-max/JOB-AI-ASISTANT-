import { useNavigate, useLocation } from "react-router";
import { useAppStore } from "@/store/appStore";
import { useAuth } from "@/hooks/useAuth";
import {
  LayoutDashboard,
  CheckSquare,
  Mail,
  Phone,
  Code2,
  Briefcase,
  Users,
  BarChart3,
  Settings,
  ChevronLeft,
  ChevronRight,
  LogOut,
  Sparkles,
} from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard, path: "/" },
  { id: "tasks", label: "Task Manager", icon: CheckSquare, path: "/tasks" },
  { id: "email", label: "Email Center", icon: Mail, path: "/email" },
  { id: "calls", label: "Call Hub", icon: Phone, path: "/calls" },
  { id: "code", label: "Code Studio", icon: Code2, path: "/code" },
  { id: "jobs", label: "Job Center", icon: Briefcase, path: "/jobs" },
  { id: "people", label: "People", icon: Users, path: "/people" },
  { id: "analytics", label: "Analytics", icon: BarChart3, path: "/analytics" },
  { id: "settings", label: "Settings", icon: Settings, path: "/settings" },
];

export function Sidebar() {
  const navigate = useNavigate();
  const location = useLocation();
  const { sidebarCollapsed, setSidebarCollapsed, agentStatus } = useAppStore();
  const { user, logout } = useAuth();

  const statusColor = {
    active: "bg-emerald-400",
    thinking: "bg-amber-400",
    idle: "bg-sky-400",
    error: "bg-red-400",
  };

  const statusText = {
    active: "Autonomous",
    thinking: "Processing",
    idle: "Idle",
    error: "Error",
  };

  return (
    <aside
      className={cn(
        "fixed left-0 top-0 h-screen bg-[#0a0f1c] border-r border-white/[0.06] flex flex-col transition-all duration-300 z-50",
        sidebarCollapsed ? "w-16" : "w-[260px]"
      )}
    >
      {/* Logo */}
      <div className="h-16 flex items-center px-4 border-b border-white/[0.06]">
        <div className="flex items-center gap-3 min-w-0">
          <div className="relative w-8 h-8 flex-shrink-0">
            <img
              src="/agent-avatar.png"
              alt="Agent"
              className="w-8 h-8 rounded-lg object-cover"
            />
            <span
              className={cn(
                "absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-[#0a0f1c] status-pulse",
                statusColor[agentStatus]
              )}
            />
          </div>
          {!sidebarCollapsed && (
            <div className="min-w-0">
              <p className="text-sm font-semibold text-white truncate">NexusAI</p>
              <p className="text-[10px] text-[#4A5570] uppercase tracking-wider flex items-center gap-1">
                <span className={cn("w-1.5 h-1.5 rounded-full", statusColor[agentStatus])} />
                {statusText[agentStatus]}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-4 px-2 space-y-1 overflow-y-auto scrollbar-thin">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => navigate(item.path)}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 group relative",
                isActive
                  ? "bg-[#00D4FF]/10 text-[#00D4FF]"
                  : "text-[#7A8BA9] hover:text-white hover:bg-white/[0.04]"
              )}
            >
              {isActive && (
                <div className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-6 gradient-accent rounded-r-full" />
              )}
              <Icon className="w-5 h-5 flex-shrink-0" />
              {!sidebarCollapsed && (
                <span className="text-sm font-medium truncate">{item.label}</span>
              )}
              {isActive && !sidebarCollapsed && (
                <Sparkles className="w-3.5 h-3.5 ml-auto text-[#00D4FF]/60" />
              )}
            </button>
          );
        })}
      </nav>

      {/* Bottom Actions */}
      <div className="p-2 border-t border-white/[0.06] space-y-1">
        <button
          onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
          className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-[#7A8BA9] hover:text-white hover:bg-white/[0.04] transition-colors"
        >
          {sidebarCollapsed ? (
            <ChevronRight className="w-4 h-4" />
          ) : (
            <>
              <ChevronLeft className="w-4 h-4" />
              <span className="text-xs">Collapse</span>
            </>
          )}
        </button>
        {user && (
          <button
            onClick={logout}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-[#7A8BA9] hover:text-red-400 hover:bg-red-400/10 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            {!sidebarCollapsed && <span className="text-xs">Logout</span>}
          </button>
        )}
      </div>
    </aside>
  );
}
