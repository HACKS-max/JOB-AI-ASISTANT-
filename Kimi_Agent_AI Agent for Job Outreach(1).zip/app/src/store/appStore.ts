import { create } from "zustand";

interface AppState {
  sidebarCollapsed: boolean;
  activeModule: string;
  isModalOpen: boolean;
  modalType: string | null;
  modalData: any;
  toastQueue: Array<{
    id: string;
    type: "success" | "error" | "warning" | "info";
    message: string;
  }>;
  agentStatus: "active" | "thinking" | "idle" | "error";
  
  setSidebarCollapsed: (collapsed: boolean) => void;
  setActiveModule: (module: string) => void;
  openModal: (type: string, data?: any) => void;
  closeModal: () => void;
  addToast: (type: "success" | "error" | "warning" | "info", message: string) => void;
  removeToast: (id: string) => void;
  setAgentStatus: (status: "active" | "thinking" | "idle" | "error") => void;
}

export const useAppStore = create<AppState>((set) => ({
  sidebarCollapsed: false,
  activeModule: "dashboard",
  isModalOpen: false,
  modalType: null,
  modalData: null,
  toastQueue: [],
  agentStatus: "active",

  setSidebarCollapsed: (collapsed) => set({ sidebarCollapsed: collapsed }),
  setActiveModule: (module) => set({ activeModule: module }),
  openModal: (type, data) => set({ isModalOpen: true, modalType: type, modalData: data }),
  closeModal: () => set({ isModalOpen: false, modalType: null, modalData: null }),
  addToast: (type, message) => {
    const id = Math.random().toString(36).substring(7);
    set((state) => ({
      toastQueue: [...state.toastQueue, { id, type, message }],
    }));
    setTimeout(() => {
      set((state) => ({
        toastQueue: state.toastQueue.filter((t) => t.id !== id),
      }));
    }, 5000);
  },
  removeToast: (id) =>
    set((state) => ({
      toastQueue: state.toastQueue.filter((t) => t.id !== id),
    })),
  setAgentStatus: (status) => set({ agentStatus: status }),
}));
